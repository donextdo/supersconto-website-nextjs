"use strict";
exports.id = 858;
exports.ids = [858];
exports.modules = {

/***/ 1858:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9989);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_io5__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _cartSlice__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5250);
/* harmony import */ var _product_productSlice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4631);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_cartSlice__WEBPACK_IMPORTED_MODULE_6__, _product_productSlice__WEBPACK_IMPORTED_MODULE_7__]);
([_cartSlice__WEBPACK_IMPORTED_MODULE_6__, _product_productSlice__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const CartCard = ({ item , index , totalAmount  })=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useDispatch)();
    const cartItems = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.cart.items);
    let totalAmount1 = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.cart.totalAmount);
    const handleCheckboxChange = ()=>{};
    const handleIncrement = (item)=>{
        const newQuantity = (item.count || 0) + 1;
        dispatch((0,_cartSlice__WEBPACK_IMPORTED_MODULE_6__/* .updateItemQuantity */ .Ol)({
            itemId: item._id,
            count: newQuantity
        }));
        dispatch((0,_product_productSlice__WEBPACK_IMPORTED_MODULE_7__/* .updateProductQuantity */ .Ic)({
            productId: item._id,
            count: newQuantity
        }));
        dispatch((0,_cartSlice__WEBPACK_IMPORTED_MODULE_6__/* .calSubTotal */ .zB)(totalAmount));
    };
    const handleDecrement = (item)=>{
        const newQuantity = Math.max((item.count || 0) - 1, 0);
        dispatch((0,_cartSlice__WEBPACK_IMPORTED_MODULE_6__/* .updateItemQuantity */ .Ol)({
            itemId: item._id,
            count: newQuantity
        }));
        dispatch((0,_product_productSlice__WEBPACK_IMPORTED_MODULE_7__/* .updateProductQuantity */ .Ic)({
            productId: item._id,
            count: newQuantity
        }));
        dispatch((0,_cartSlice__WEBPACK_IMPORTED_MODULE_6__/* .calSubTotal */ .zB)(totalAmount));
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        console.log(cartItems);
    });
    const handleDelete = (_id)=>{
        dispatch((0,_cartSlice__WEBPACK_IMPORTED_MODULE_6__/* .removeItem */ .cl)(_id));
        dispatch((0,_cartSlice__WEBPACK_IMPORTED_MODULE_6__/* .calSubTotal */ .zB)(totalAmount));
    };
    let discountprice;
    discountprice = item.unit_price * (item.discount / 100);
    let newprice = item.unit_price - discountprice;
    let subtotal = item.count * newprice;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "grid grid-cols-4 sm:grid-cols-12 grid-2 gap-1 border-b border-[#71778e] py-3 h-28 items-center relative bg-white",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "h-[95px] sm:col-span-2",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                    src: item.product_image,
                    alt: "item1",
                    style: {
                        objectFit: "contain",
                        backgroundColor: "#e5e7eb",
                        width: "100%",
                        height: "100%"
                    },
                    width: 450,
                    height: 400
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "col-span-2 sm:col-span-4 text-sm ",
                children: item.product_name
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "col-span-1 hidden sm:block",
                children: newprice.toFixed(2)
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex sm:col-span-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "p-2 bg-[#008C45] rounded-full w-[30px] flex items-center",
                        onClick: ()=>handleDecrement(item),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__.FaMinus, {
                            className: "text-xs"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        className: "text-sm flex items-center justify-center w-7 mx-1",
                        children: item.count || 0
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "p-2 bg-[#008C45] rounded-full w-[30px] flex items-center",
                        onClick: ()=>handleIncrement(item),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__.FaPlus, {
                            className: "text-xs "
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "col-span-2 hidden sm:block",
                children: subtotal.toFixed(2)
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "col-span-1 hidden sm:block",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: "bg-[#e5e7eb] rounded-full p-1",
                    onClick: ()=>handleDelete(item._id),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_4__.IoCloseSharp, {
                        className: "text-xl font-semibold text-black"
                    })
                })
            })
        ]
    }, index);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CartCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;