"use strict";
exports.id = 56;
exports.ids = [56];
exports.modules = {

/***/ 7056:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Wf": () => (/* binding */ getOrdersByUserIdAsync),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports insertOrderAsync, addOrder */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
/* harmony import */ var _utils_request__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1583);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__, _utils_request__WEBPACK_IMPORTED_MODULE_2__]);
([axios__WEBPACK_IMPORTED_MODULE_1__, _utils_request__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const initialState = {
    orders: [],
    status: "idle",
    error: null
};
// const PRODUCTS_URL = `${baseUrl}/orders/get`;
// const PRODUCTS_URL_SET = `${baseUrl}/orders/place`;
const insertOrderAsync = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("order/insertOrderAsync", async (orderObj)=>{
    console.log("Response object:", orderObj);
    const response = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post("/orders/place", orderObj);
    return response.data;
});
const getOrdersByUserIdAsync = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("order/getOrdersByUserIdAsync", async (id)=>{
    console.log("Response data:", id);
    const res = await _utils_request__WEBPACK_IMPORTED_MODULE_2__/* .http.get */ .d.get(`/neworder/get/${id}`);
    console.log("Response data:", res.data);
    return res.data;
});
const orderSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "order",
    initialState,
    reducers: {
        addOrder: (state, action)=>{
            console.log("Adding order:", action.payload);
            state.orders.push(action.payload);
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(insertOrderAsync.pending, (state)=>{
            state.status = "loading";
        }).addCase(insertOrderAsync.fulfilled, (state, action)=>{
            state.orders.push(action.payload);
            state.status = "succeeded";
        }).addCase(insertOrderAsync.rejected, (state, action)=>{
            state.error = action.error.message ?? "Failed to insert order";
            state.status = "failed";
        }).addCase(getOrdersByUserIdAsync.pending, (state)=>{
            state.status = "loading";
        }).addCase(getOrdersByUserIdAsync.fulfilled, (state, action)=>{
            state.orders = action.payload;
            state.status = "succeeded";
        }).addCase(getOrdersByUserIdAsync.rejected, (state, action)=>{
            state.error = action.error.message ?? "Failed to get orders";
            state.status = "failed";
        });
    }
});
const { addOrder  } = orderSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (orderSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;