"use strict";
exports.id = 631;
exports.ids = [631];
exports.modules = {

/***/ 4631:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ic": () => (/* binding */ updateProductQuantity),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "t2": () => (/* binding */ fetchProducts)
/* harmony export */ });
/* unused harmony exports productSlice, setProducts */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_request__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1583);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_request__WEBPACK_IMPORTED_MODULE_1__]);
_utils_request__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

// import baseUrl from "../../../utils/baseUrl";

const initialState = {
    products: [],
    status: "idle",
    error: null,
    cnt: 2
};
const PRODUCTS_URL = (/* unused pure expression or super */ null && (`/product/getAll/`));
const fetchProducts = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("product/fetchProducts", async ()=>{
    const response = await _utils_request__WEBPACK_IMPORTED_MODULE_1__/* .http.get */ .d.get("http://localhost:3000/v1/api/catelog/item");
    console.log(response.data);
    return response.data;
});
const productSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "product",
    initialState,
    reducers: {
        setProducts: (state, action)=>{
            state.products = action.payload;
        },
        updateProductQuantity: (state, action)=>{
            const product = state.products.find((p)=>p._id === action.payload.productId);
            if (product) {
                product.count = action.payload.count;
                console.log(state.products);
            }
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(fetchProducts.pending, (state)=>{
            state.status = "loading";
        }).addCase(fetchProducts.fulfilled, (state, action)=>{
            state.status = "succeeded";
            state.products = action.payload;
        }).addCase(fetchProducts.rejected, (state, action)=>{
            state.status = "failed";
            state.error = action.error.message ?? "Unknown error";
        });
    }
});
const { setProducts , updateProductQuantity  } = productSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (productSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;