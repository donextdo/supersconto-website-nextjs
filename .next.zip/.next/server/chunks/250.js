"use strict";
exports.id = 250;
exports.ids = [250];
exports.modules = {

/***/ 5250:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ol": () => (/* binding */ updateItemQuantity),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "cl": () => (/* binding */ removeItem),
/* harmony export */   "jX": () => (/* binding */ addItem),
/* harmony export */   "xY": () => (/* binding */ removeAll),
/* harmony export */   "zB": () => (/* binding */ calSubTotal)
/* harmony export */ });
/* unused harmony exports fetchCart, cartSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_request__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1583);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_request__WEBPACK_IMPORTED_MODULE_1__]);
_utils_request__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const initialState = {
    items: [],
    totalCount: 0,
    totalAmount: 0,
    status: "idle",
    error: null
};
// const PRODUCTS_URL = `${baseUrl}/orders/place`;
const fetchCart = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("cart/fetchCart", async ()=>{
    const response = await _utils_request__WEBPACK_IMPORTED_MODULE_1__/* .http.post */ .d.post("/orders/place");
    return response.data;
});
const cartSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "cart",
    initialState,
    reducers: {
        addItem: (state, action)=>{
            console.log(action.payload);
            const itemIndex = state.items.findIndex((item)=>item._id === action.payload._id);
            if (itemIndex === -1) {
                state.items.push({
                    ...action.payload,
                    count: 1
                });
            } else {
                state.items[itemIndex].count++;
            }
            state.totalCount++;
        },
        removeItem: (state, action)=>{
            const itemIndex = state.items.findIndex((item)=>item._id === action.payload);
            if (itemIndex !== -1) {
                const count = state.items[itemIndex].count;
                state.items.splice(itemIndex, 1);
                state.totalCount -= count;
            }
        },
        updateItemQuantity: (state, action)=>{
            const item = state.items.find((item)=>item._id === action.payload.itemId);
            if (item) {
                const countDiff = action.payload.count - item.count;
                item.count = action.payload.count;
                state.totalCount += countDiff;
            }
        },
        removeAll: (state)=>{
            state.items = [];
            state.totalCount = 0;
            state.totalAmount = 0;
        },
        calSubTotal: (state, action)=>{
            // console.log('Order inserted:', action.payload);
            state.totalAmount = action.payload;
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(fetchCart.pending, (state)=>{
            state.status = "loading";
        }).addCase(fetchCart.fulfilled, (state, action)=>{
            state.status = "succeeded";
            state.items = action.payload;
        }).addCase(fetchCart.rejected, (state, action)=>{
            state.status = "failed";
            state.error = action.error.message ?? "Unknown error";
        });
    }
});
const { addItem , removeItem , updateItemQuantity , removeAll , calSubTotal  } = cartSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (cartSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1583:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "d": () => (/* binding */ http)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const BASE_URL = "https://api.supersconto24.com/v1/api";
// const BASE_URL = 'http://localhost:3000/v1/api'
const requests = {
    fetchCatelogs: `${BASE_URL}/catelog/book`,
    findCatalogById: (id)=>`${BASE_URL}/catelog/book/find/${id}`,
    getCatalogBookPageItemByIds: `${BASE_URL}/catelog/item/find-list`,
    getLatestItemId: `${BASE_URL}/catelog/item`,
    allShops: `${BASE_URL}/shop`,
    findShopById: (id)=>`${BASE_URL}/shop/find/${id}`,
    allNews: `${BASE_URL}/news`,
    allCategory: `${BASE_URL}/category/categories`
};
const http = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: BASE_URL,
    timeout: 2000,
    headers: {
        "X-Custom-Header": "foobar"
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (requests);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;