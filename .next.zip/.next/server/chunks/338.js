exports.id = 338;
exports.ids = [338];
exports.modules = {

/***/ 2690:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Utils_TextInput__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4691);
/* harmony import */ var _assets_logo_logo_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4234);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_sl__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5065);
/* harmony import */ var react_icons_sl__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_sl__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_tfi__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1740);
/* harmony import */ var react_icons_tfi__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_tfi__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _Language_Language__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5474);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _UserProfile___WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(238);
/* harmony import */ var _features_cart_popup_cart_CartPopup__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2203);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(4298);
/* harmony import */ var next_script__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(next_script__WEBPACK_IMPORTED_MODULE_15__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_features_cart_popup_cart_CartPopup__WEBPACK_IMPORTED_MODULE_13__]);
_features_cart_popup_cart_CartPopup__WEBPACK_IMPORTED_MODULE_13__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


// import { FaBars } from 'react-icons/fa'














const Header = ()=>{
    const [query, setQuery] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [location, setLocation] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [languagePopup, setLanguagePopup] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [isLoggedIn, setIsLoggedIn] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [cart, setCart] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const totalCount = (0,react_redux__WEBPACK_IMPORTED_MODULE_14__.useSelector)((state)=>state.cart.totalCount);
    const [predictions, setPredictions] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [hide, setHide] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [latitude, setLatitude] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [longitude, setLongitude] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [formatAddress, setFormatAddress] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const token = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (typeof localStorage !== "undefined") {
            return localStorage.getItem("token");
        }
        return null;
    }, []);
    const email = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        if (typeof localStorage !== "undefined") {
            return localStorage.getItem("email");
        }
        return null;
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (token) {
            setIsLoggedIn(true);
        }
    }, []);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const handleChange = (e)=>{
        setQuery(e.target.value);
    };
    // const handleLocationChange = (
    //   e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
    // ) => {
    //   setLocation(e.target.value);
    // };
    const handleLocationChange = (event)=>{
        setLocation(event.target.value);
        const location = event.target.value;
        const autocompleteService = new google.maps.places.AutocompleteService();
        autocompleteService.getPlacePredictions({
            input: location,
            types: [
                "geocode"
            ]
        }, handleAutocompleteResults);
    };
    const handleAutocompleteResults = (predictions, status)=>{
        setHide(false);
        if (status === google.maps.places.PlacesServiceStatus.OK) {
            setPredictions(predictions);
            console.log("prediction : ", predictions);
        }
    };
    function handlePredictionClick(place_id) {
        setHide(false);
        console.log("place_id: ", place_id);
        const placeService = new google.maps.places.PlacesService(document.createElement("div"));
        console.log("placeService: ", placeService);
        placeService.getDetails({
            placeId: place_id
        }, (placeResult, placeStatus)=>{
            console.log("placeResult: ", placeResult);
            if (placeStatus === google.maps.places.PlacesServiceStatus.OK && placeResult) {
                const lat = placeResult.geometry?.location?.lat();
                const lng = placeResult.geometry?.location?.lng();
                const formattedAddress = placeResult.formatted_address;
                console.log("Formatted Address: ", formattedAddress);
                setLatitude(lat);
                setLongitude(lng);
                setLocation(formattedAddress);
                setFormatAddress(location);
            }
        });
    }
    const handleSearch = ()=>{
        router.push(`/search-results?query=${query}`);
    };
    const handleLocationSearch = ()=>{
        console.log("location empty : ", location);
        if (!location) {
            navigator.geolocation.getCurrentPosition((position)=>{
                const lat = position.coords.latitude;
                const lng = position.coords.longitude;
                console.log("position : ", position);
                // setLocation(`${lat}, ${lng}`);
                getAddressFromCoordinates(lat, lng);
                setHide(true);
            }, (error)=>{
                console.error(error);
            });
        } else {
            getAddressFromCoordinates(Number(latitude), Number(longitude));
            setHide(true);
        }
    };
    function getAddressFromCoordinates(lat, lng) {
        const geocoder = new google.maps.Geocoder();
        const latLng = new google.maps.LatLng(lat, lng);
        geocoder.geocode({
            location: latLng
        }, (results, status)=>{
            if (status === google.maps.GeocoderStatus.OK && results && results.length > 0) {
                const formattedAddress = results[0].formatted_address;
                console.log("Formatted Address: ", formattedAddress);
                // Use the formatted address as needed
                setLocation(formattedAddress);
            }
        });
    }
    const { i18n  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_11__.useTranslation)();
    const handleLanguage = ()=>{
        setLanguagePopup(!languagePopup);
    };
    function handleChangeLanguage(language) {
    // const language = event.target.value;
    // i18n.changeLanguage('it');
    // i18n.changeLanguage('en')
    }
    function handleKeyDown(event) {
        if (event.key === "Enter") {
            //   console.log("Enter key pressed!");
            router.push(`/search-results?query=${query}`);
        // Add your code here to handle the Enter key press
        }
    }
    const handleProfile = ()=>{
        if (token) {
            router.push("/account");
        } else {
            router.push("/LoginRegister");
        }
    };
    const handleClick = ()=>{
    // setCart(!cart)
    };
    const hnadleEnter = ()=>{
        setCart(true);
    };
    const handleLeave = ()=>{
        setCart(false);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex items-center w-full px-10 ",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex items-center w-full gap-4 pl-16 lsm:pl-0",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        href: "/",
                        className: "text-3xl text-[#008C45] font-semibold ",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                            src: _assets_logo_logo_png__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                            alt: "LOGO",
                            className: "w-auto h-11 sm:h-9 md:h-11"
                        })
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex items-center gap-4 text-right",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                            className: "hidden md:block",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center flex-raw",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Utils_TextInput__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        value: query,
                                        onChange: handleChange,
                                        onKeyDown: handleKeyDown,
                                        Styles: "bg-[#EDEDED] text-[#3D3B3B] text-sm font-light md:w-48 lg:w-60 xl:w-96 rounded-md h-[40px]",
                                        placeholder: "Search by Category or Items"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        disabled: !query,
                                        onClick: handleSearch,
                                        className: "relative",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_6__.FaSearch, {
                                            className: "absolute text-white bg-[#008C45] w-12 h-[40px] px-4 -left-8 -bottom-[20px] rounded-r-md"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                            className: "hidden md:block",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex items-center ml-8 flex-raw lg:ml-20",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_script__WEBPACK_IMPORTED_MODULE_15___default()), {
                                        src: `https://maps.googleapis.com/maps/api/js?key=AIzaSyALJN3bDbGEk8ppXieiWNnwHVYM_8ntKng&libraries=places`,
                                        onLoad: ()=>console.log("Google Maps API script loaded")
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "relative w-full",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Utils_TextInput__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                                value: location,
                                                onChange: handleLocationChange,
                                                Styles: "bg-[#EDEDED] text-[#3D3B3B] text-sm font-light md:w-48 lg:w-60 xl:w-96 rounded-l-md h-[40px]",
                                                placeholder: "Search by Location"
                                            }),
                                            predictions.length > 0 && !hide && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                                className: "absolute top-full left-0 w-full bg-white z-10 border border-gray-300 rounded-md shadow-lg",
                                                children: predictions.map((prediction)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "px-4 py-2 hover:bg-gray-100 cursor-pointer w-full text-left",
                                                        onClick: ()=>handlePredictionClick(prediction.place_id),
                                                        children: prediction.description
                                                    }, prediction.place_id))
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                className: "absolute right-0 top-0 bottom-0",
                                                onClick: handleLocationSearch,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_6__.FaLocationArrow, {
                                                    className: "text-white bg-blue-400 w-12 h-[40px] px-4 rounded-r-md"
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "ml-10 lg:ml-16",
                            onClick: handleLanguage,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_tfi__WEBPACK_IMPORTED_MODULE_8__.TfiWorld, {
                                className: "fill-[#008C45] w-6 h-6 "
                            })
                        }),
                        languagePopup && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Language_Language__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            setLanguagePopup: setLanguagePopup,
                            handleChangeLanguage: handleChangeLanguage
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "relative",
                            onMouseEnter: hnadleEnter,
                            onMouseLeave: handleLeave,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "border border-[#fff1ee] bg-[#fff1ee] rounded-full p-2",
                                    onClick: handleClick,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_sl__WEBPACK_IMPORTED_MODULE_7__.SlHandbag, {
                                        className: "text-2xl text-[#ea2b0f]"
                                    })
                                }),
                                cart && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_features_cart_popup_cart_CartPopup__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                    setCart: setCart
                                }),
                                totalCount > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "absolute -top-2 -right-2 bg-red-500 text-white rounded-full h-5 w-5 flex items-center justify-center",
                                    children: totalCount
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "ml-4 lg:ml-8 border bg-green-700 border-green-700 rounded-full shadow-lg hover:bg-gray-200 w-10 h-10 flex items-center justify-center ",
                                onClick: handleProfile,
                                children: isLoggedIn ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UserProfile___WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                    email: email
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_sl__WEBPACK_IMPORTED_MODULE_7__.SlUser, {
                                    className: "fill-[#FFFFFF] w-6 h-6"
                                })
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Header);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 238:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const UserProfile = ({ email  })=>{
    let initials = "A";
    if (email) {
        initials = email?.charAt(0).toUpperCase();
    } else {}
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "text-xl font-semibold text-white",
        children: initials
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserProfile);


/***/ }),

/***/ 5474:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8547);
/* harmony import */ var react_icons_gr__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_gr__WEBPACK_IMPORTED_MODULE_2__);



const Language = ({ setLanguagePopup , handleChangeLanguage  })=>{
    const [selected, setSelected] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const [border, setBorder] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [currencySelected, setCurrencySelected] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    //   const handlesClick = (id:any) => {
    //     setSelected(selected === id ? null : id);
    //   }
    const handlesSubmit = (id)=>{
        setBorder(border === id ? null : id);
        handleChangeLanguage("it");
    };
    const handleLanguageClick = (id)=>{
        setSelected(id);
        setCurrencySelected(null);
    };
    const handleCurrencyClick = (id)=>{
        setCurrencySelected(id);
        setSelected(0);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "fixed inset-0 z-50 bg-slate-900 bg-opacity-0 flex justify-end top-16 right -0 md:right-32 max-h-[600px] h-60 ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "py-4 px-8 flex gap-4 flex-col bg-gray-50 shadow-md rounded-lg w-full md:w-[400px]",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: "py-1 text-xl text-right rounded-sm ",
                    onClick: ()=>setLanguagePopup(false),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_gr__WEBPACK_IMPORTED_MODULE_2__.GrFormClose, {})
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex px-2 space-x-8",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: `border-b-[3px] py-2  ${selected === 1 ? "border-[#008C45] text-black " : "text-gray-600"}`,
                            onClick: ()=>handleLanguageClick(1),
                            children: "Language and Region"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: `border-b-[3px] py-2  ${currencySelected === 2 ? "border-[#008C45] text-black" : "text-gray-600"}`,
                            onClick: ()=>handleCurrencyClick(2),
                            children: "Currency"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: ` space-x-4 ${selected !== 1 ? "hidden " : ""}`,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                            className: `border-2 rounded-md w-40 h-16 ${border === 1 ? "border-black text-black " : "text-gray-600"}`,
                            onClick: ()=>handlesSubmit(1),
                            children: [
                                "Italiano ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-gray-500",
                                    children: "Italia"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                            className: `border-2 rounded-md w-40 h-16 ${border === 2 ? "border-black text-black " : "text-gray-600"}`,
                            onClick: ()=>handlesSubmit(2),
                            children: [
                                "English ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-gray-500",
                                    children: "United Kindom"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: ` space-x-4 ${currencySelected !== 2 ? "hidden " : ""}`,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                            className: `border-2 rounded-md w-40 h-16 ${border === 3 ? "border-black text-black " : "text-gray-600"}`,
                            onClick: ()=>handlesSubmit(3),
                            children: [
                                "Euro",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-gray-500",
                                    children: "EUR - Є"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                            className: `border-2 rounded-md w-40 h-16 ${border === 4 ? "border-black text-black " : "text-gray-600"}`,
                            onClick: ()=>handlesSubmit(4),
                            children: [
                                "Dollar ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-gray-500",
                                    children: "USD - $"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Language);


/***/ }),

/***/ 4691:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const TextInput = ({ id , label , error , errorMessage , type , value , Styles , border , borderColor , placeholder , onChange , onKeyDown  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col gap-2 items-start",
        children: [
            label && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                className: `text-sm font-medium ${error ? "text-red-600" : "text-gray-900"}`,
                children: label
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                id: id,
                type: type ? type : "text",
                value: value,
                className: `${Styles ? Styles : "text-sm font-medium bg-white"} w-full px-6 py-2 focus:outline-none ${border && "border"} ${border && error ? "border-red-600" : borderColor} `,
                placeholder: placeholder,
                onChange: onChange,
                onKeyDown: onKeyDown
            }),
            error && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                className: "text-xs text-red-600",
                children: errorMessage
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TextInput);


/***/ }),

/***/ 4298:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

module.exports = __webpack_require__(3573)


/***/ })

};
;