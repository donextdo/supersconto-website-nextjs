(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 4234:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/logo.e88bf3c6.png","height":155,"width":500,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAATUlEQVR4nGOMW5qfysTIZCzAynOamZmN7+jXh59+MjJ812Tg/Fl9R+gMY9rysoAPvz7x/WZmFpf/w2yj8vH3449/vnxX5VF8ZfKA8TQASHMdDPr3Ca4AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":2});

/***/ }),

/***/ 3847:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ App)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6764);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(782);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _src_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3582);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _src_redux_store__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1922);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_redux_store__WEBPACK_IMPORTED_MODULE_6__]);
_src_redux_store__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// import '../styles/app.css'







function App({ Component , pageProps  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_redux__WEBPACK_IMPORTED_MODULE_5__.Provider, {
        store: _src_redux_store__WEBPACK_IMPORTED_MODULE_6__/* .store */ .h,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Layout_Layout__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                ...pageProps
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3582:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout_Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: ./assets/logo/logo.png
var logo = __webpack_require__(4234);
;// CONCATENATED MODULE: ./src/components/Footer/Footer.tsx




const Footer = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("footer", {
        className: "py-4 bg-ray-200",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "px-16 mx-auto ",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "grid grid-cols-1 gap-4 sm:grid-cols-5 xl:grid-cols-4 ",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "col-span-1 pr-4 sm:col-span-2 xl:col-span-1",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: logo/* default */.Z,
                                    alt: "logo",
                                    className: "w-auto h-16"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "my-2",
                                    children: "Shop the best of Italian foods, grocery items , beauty, and home decor on our multivendor website. Find unique products from top vendors across Italy, all in one place. Shop now and add a touch of Italian elegance to your life with amazing\xa0discounts."
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex my-3 space-x-2",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaFacebookSquare, {
                                            className: "fill-[#CD212A]"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaTwitter, {
                                            className: "fill-[#CD212A]"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaInstagram, {
                                            className: "fill-[#CD212A]"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaLinkedin, {
                                            className: "fill-[#CD212A]"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mt-8 space-y-4 lg:ml-16",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "my-2 font-semibold",
                                    children: "ARE YOU A USER?"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "my-2",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "#",
                                                children: "About Super Sconto 24"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "my-2",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "#",
                                                children: "How it works"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "my-2",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "#",
                                                children: "Download app"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "my-2",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "#",
                                                children: "Write to us"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "my-2",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "#",
                                                children: "Echo"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mt-8 space-y-4 lg:ml-10",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "my-2 font-semibold",
                                    children: "ARE YOU A COMPANY?"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "my-2",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "#",
                                                children: "Corporate"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "my-2",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "",
                                                children: "Who are we"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "my-2",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "",
                                                children: "Smart solution"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "my-2",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "",
                                                children: "work with us"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "my-2",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "",
                                                children: "Commercial inquiries"
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "mt-8 space-y-4 lg:ml-10",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: "my-2 font-semibold",
                                    children: "INDEX"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "my-2",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "#",
                                                children: "Marche"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "my-2",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "",
                                                children: "Shops"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "my-2",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "",
                                                children: "Categories"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "my-2",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "",
                                                children: "Loyality cards"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                            className: "my-2",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                href: "",
                                                children: "City"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                    className: "my-8 h-px bg-[#000000] border-0"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    children: "Copyrights \xa9 2023 All Rights Reserved"
                })
            ]
        })
    });
};
/* harmony default export */ const Footer_Footer = (Footer);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/components/Layout/Layout.tsx



const Layout = ({ children  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "space-y-10",
        children: [
            children,
            /*#__PURE__*/ jsx_runtime_.jsx(Footer_Footer, {})
        ]
    });
};
/* harmony default export */ const Layout_Layout = (Layout);


/***/ }),

/***/ 5235:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports createUserAsync, getUserAsync, updateUser */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
/* harmony import */ var _utils_request__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1583);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_1__, _utils_request__WEBPACK_IMPORTED_MODULE_2__]);
([axios__WEBPACK_IMPORTED_MODULE_1__, _utils_request__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const initialState = {
    user: null,
    status: "idle",
    error: null
};
// const USER_URL = `${baseUrl}/users`;
const createUserAsync = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("user/createUserAsync", async (userData)=>{
    const response = await _utils_request__WEBPACK_IMPORTED_MODULE_2__/* .http.post */ .d.post("/users", userData);
    return response.data;
});
const getUserAsync = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("user/getUserAsync", async (userId)=>{
    const response = await axios__WEBPACK_IMPORTED_MODULE_1__["default"].get(`/users/${userId}`);
    console.log("Response data:", response.data);
    return response.data;
});
const userSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "user",
    initialState,
    reducers: {
        updateUser: (state, action)=>{
        // state.user = { ...state.user, ...action.payload };
        }
    },
    extraReducers: (builder)=>{
        builder.addCase(createUserAsync.pending, (state)=>{
            state.status = "loading";
        }).addCase(createUserAsync.fulfilled, (state, action)=>{
            state.user = action.payload;
            state.status = "succeeded";
        }).addCase(createUserAsync.rejected, (state, action)=>{
            state.error = action.error.message ?? "Failed to create user";
            state.status = "failed";
        }).addCase(getUserAsync.pending, (state)=>{
            state.status = "loading";
        }).addCase(getUserAsync.fulfilled, (state, action)=>{
            state.user = action.payload;
            state.status = "succeeded";
        }).addCase(getUserAsync.rejected, (state, action)=>{
            state.error = action.error.message ?? "Failed to get user";
            state.status = "failed";
        });
    }
});
const { updateUser  } = userSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (userSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1922:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ store)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _features_product_productSlice__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4631);
/* harmony import */ var _features_cart_cartSlice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5250);
/* harmony import */ var _components_Checkout_orderSlice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7056);
/* harmony import */ var _features_User_userSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5235);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_features_product_productSlice__WEBPACK_IMPORTED_MODULE_1__, _features_cart_cartSlice__WEBPACK_IMPORTED_MODULE_2__, _components_Checkout_orderSlice__WEBPACK_IMPORTED_MODULE_3__, _features_User_userSlice__WEBPACK_IMPORTED_MODULE_4__]);
([_features_product_productSlice__WEBPACK_IMPORTED_MODULE_1__, _features_cart_cartSlice__WEBPACK_IMPORTED_MODULE_2__, _components_Checkout_orderSlice__WEBPACK_IMPORTED_MODULE_3__, _features_User_userSlice__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({
    reducer: {
        product: _features_product_productSlice__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .ZP,
        cart: _features_cart_cartSlice__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP,
        order: _components_Checkout_orderSlice__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP,
        user: _features_User_userSlice__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP
    }
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 782:
/***/ (() => {



/***/ }),

/***/ 8278:
/***/ (() => {



/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [121,675,250,631,56], () => (__webpack_exec__(3847)));
module.exports = __webpack_exports__;

})();