(() => {
var exports = {};
exports.id = 24;
exports.ids = [24];
exports.modules = {

/***/ 7033:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/arrow-next.5949601b.svg","height":20,"width":20});

/***/ }),

/***/ 1458:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/arrow-prev.a4498732.svg","height":20,"width":20});

/***/ }),

/***/ 330:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "NextArrowCircle": () => (/* binding */ NextArrowCircle),
/* harmony export */   "PrevArrowCircle": () => (/* binding */ PrevArrowCircle),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_request__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1583);
/* harmony import */ var _public_arrow_next_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7033);
/* harmony import */ var _public_arrow_prev_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1458);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _src_components_Cart_AddCartModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6309);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(782);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _src_components_Draggable_Draggable__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5651);
/* harmony import */ var _assets_logo_logo_png__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4234);
/* harmony import */ var _src_components_Cart_NavbarCartModal__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5607);
/* harmony import */ var react_icons_sl__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5065);
/* harmony import */ var react_icons_sl__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_icons_sl__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _src_features_cart_popup_cart_CartPopup__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2203);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_16__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_request__WEBPACK_IMPORTED_MODULE_2__, _src_components_Cart_AddCartModal__WEBPACK_IMPORTED_MODULE_6__, _src_components_Draggable_Draggable__WEBPACK_IMPORTED_MODULE_11__, _src_components_Cart_NavbarCartModal__WEBPACK_IMPORTED_MODULE_13__, _src_features_cart_popup_cart_CartPopup__WEBPACK_IMPORTED_MODULE_15__]);
([_utils_request__WEBPACK_IMPORTED_MODULE_2__, _src_components_Cart_AddCartModal__WEBPACK_IMPORTED_MODULE_6__, _src_components_Draggable_Draggable__WEBPACK_IMPORTED_MODULE_11__, _src_components_Cart_NavbarCartModal__WEBPACK_IMPORTED_MODULE_13__, _src_features_cart_popup_cart_CartPopup__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















const CatalogCarousel = ({ catalog  })=>{
    const [pages, setPages] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [showModal, setShowModal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        show: false,
        item: null
    });
    const [settings, setSettings] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 2,
        slidesToScroll: 2,
        nextArrow: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NextArrowCircle, {}),
        prevArrow: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PrevArrowCircle, {})
    });
    const [windowInfo, setWindowInfo] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        width: 0,
        height: 0
    });
    const [showCart, setShowCart] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const ref = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const [changecolor, setChangecolor] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [cart, setCart] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const totalCount = (0,react_redux__WEBPACK_IMPORTED_MODULE_16__.useSelector)((state)=>state.cart.totalCount);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        console.log(catalog);
        if (catalog.length > 0) {
            setPages(catalog[0].pages);
            if (catalog[0].pages.length === 1) {
                setSettings((prevState)=>({
                        ...prevState,
                        slidesToScroll: 1,
                        slidesToShow: 1
                    }));
            }
        }
    }, [
        catalog
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        function handleClickOutside(event) {
            if (ref.current && !ref.current.contains(event.target)) {
                setShowCart(false);
            }
        }
        document.addEventListener("mousedown", handleClickOutside);
        return ()=>{
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [
        ref
    ]);
    //   const getItemCount = () => {
    //     let count = 0
    //     let totol = 0
    //   if (cartObj) {
    //       Object.keys(cartObj).forEach(shop => {
    //           count += cartObj[shop].length
    //           cartObj[shop].forEach((item: { cartQuantity: number; }) => {
    //               totol += item.cartQuantity
    //           })
    //       })
    //   }
    //   return `${count} (${totol})`
    // }
    const originalDate = new Date(catalog[0].expiredate);
    const formattedDate = new Date(originalDate).toLocaleDateString("en-GB");
    // console.log(formattedDate);
    const handleCart = ()=>{
        setShowCart(!showCart);
    };
    console.log(windowInfo);
    const handleClick = ()=>{
    // setCart(!cart)
    };
    const hnadleEnter = ()=>{
        setCart(true);
    };
    const handleLeave = ()=>{
        setCart(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "catalog-page",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "catalog-header",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-between mx-2 items-center py-4",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "ml-12 ",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                                href: "/",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        src: _assets_logo_logo_png__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z,
                                        alt: "LOGO",
                                        className: "h-11 sm:h-9 md:h-11 w-auto"
                                    }),
                                    " "
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "text-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    children: catalog[0].title
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                    children: [
                                        "Expire Date -",
                                        formattedDate
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "relative mr-2",
                            onMouseEnter: hnadleEnter,
                            onMouseLeave: handleLeave,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "border border-[#fff1ee] bg-[#fff1ee] rounded-full p-2",
                                    onClick: handleClick,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_sl__WEBPACK_IMPORTED_MODULE_14__.SlHandbag, {
                                        className: "text-2xl text-[#ea2b0f]"
                                    })
                                }),
                                cart && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_features_cart_popup_cart_CartPopup__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                    setCart: setCart
                                }),
                                totalCount > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "absolute -top-2 -right-2 bg-red-500 text-white rounded-full h-5 w-5 flex items-center justify-center",
                                    children: totalCount
                                })
                            ]
                        }),
                        showCart && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Cart_NavbarCartModal__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                            ref: ref
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "catalog-component",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                        href: "/",
                        className: "fixed left-2 top-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "text-4xl z-50 bg-[#8DC14F] rounded-full ",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_8__.FaAngleLeft, {
                                className: "text-white"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Draggable_Draggable__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                        pages: pages,
                        setShowModal: setShowModal,
                        changecolor: changecolor
                    }),
                    showModal.show && showModal.item && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Cart_AddCartModal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        item: showModal.item,
                        setChangecolor: setChangecolor,
                        handler: ()=>setShowModal((prevState)=>({
                                    ...prevState,
                                    show: false
                                }))
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CatalogCarousel);
const getServerSideProps = async (context)=>{
    const catalog = await Promise.all([
        fetch(_utils_request__WEBPACK_IMPORTED_MODULE_2__/* ["default"].findCatalogById */ .Z.findCatalogById(context.query.catalogId)).then((res)=>res.json())
    ]);
    console.log(catalog);
    return {
        props: {
            catalog: catalog
        }
    };
};
function NextArrowCircle({ className , style , onClick  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `${className}`,
        style: style,
        onClick: onClick,
        draggable: false,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
            fill: true,
            src: _public_arrow_next_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
            alt: ""
        })
    });
}
function PrevArrowCircle({ className , style , onClick  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: `${className}`,
        style: style,
        onClick: onClick,
        draggable: false,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
            fill: true,
            src: _public_arrow_prev_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
            alt: ""
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6309:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _features_cart_cartSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5250);
/* harmony import */ var _features_product_productSlice__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4631);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_features_cart_cartSlice__WEBPACK_IMPORTED_MODULE_4__, _features_product_productSlice__WEBPACK_IMPORTED_MODULE_5__]);
([_features_cart_cartSlice__WEBPACK_IMPORTED_MODULE_4__, _features_product_productSlice__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const AddToCartModal = ({ item , handler , setChangecolor  })=>{
    // const [count, setCount] = useState(1);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useDispatch)();
    const products = (0,react_redux__WEBPACK_IMPORTED_MODULE_3__.useSelector)((state)=>state.product.products);
    // useEffect(() => {
    //     const cartItems: [any] = JSON.parse(localStorage.getItem("cartItems")!) ?? []
    //     const product = cartItems.find(it => it._id === item._id)
    //     if (product) {
    //         setCount(product.quantity >= item.quantity ? item.quantity : product.quantity)
    //     }
    // }, [item])
    const prodcutone = products.find((product)=>product._id === item._id);
    console.log(products);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{});
    const decreaseClick = ()=>{
        // if (count > 0) {
        //     setCount(prevState => prevState - 1);
        // } else {
        //     setCount(0);
        // }
        const newQuantity = Math.max((prodcutone.count || 0) - 1, 0);
        dispatch((0,_features_cart_cartSlice__WEBPACK_IMPORTED_MODULE_4__/* .updateItemQuantity */ .Ol)({
            itemId: item._id,
            count: newQuantity
        }));
        dispatch((0,_features_product_productSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateProductQuantity */ .Ic)({
            productId: item._id,
            count: newQuantity
        }));
        if (item.count === 1) {
        // dispatch(removeFromCart(id))
        // setIsAddToCart(false)
        }
    };
    const increaseClick = ()=>{
        // setCount(prevState => {
        //     if (prevState + 1 >= item.quantity) {
        //         return item.quantity
        //     }
        //     return prevState + 1
        // });
        const newQuantity = (prodcutone.count || 0) + 1;
        dispatch((0,_features_cart_cartSlice__WEBPACK_IMPORTED_MODULE_4__/* .updateItemQuantity */ .Ol)({
            itemId: item._id,
            count: newQuantity
        }));
        dispatch((0,_features_product_productSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateProductQuantity */ .Ic)({
            productId: item._id,
            count: newQuantity
        }));
    };
    console.log({
        item
    });
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "fixed inset-0 z-50 grid bg-opacity-75 place-items-center bg-slate-900",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "md:py-6 py-0 pt-3 px-4 flex md:gap-6 flex-col relative bg-white shadow-md rounded-md w-[60vw]",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "bg-white rounded-full text-end",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "px-3 text-xl font-bold text-black md:px-6",
                        onClick: handler,
                        children: "X"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                    className: "md:gap-4 md:flex",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "md:mt-2 h-[50vh] md:w-4/6 md:ml-4 relative",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                src: item.product_image,
                                fill: true,
                                style: {
                                    objectFit: "contain"
                                },
                                alt: item.product_name
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "mx-5 md:mt-8 md:mx-10 md:w-1/2 md:col-2 md:span-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-2xl font-bold text-center md:text-left",
                                        children: item.product_name
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "flex gap-4 mt-6 md:gap-16 flex-raw",
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "text-lg ",
                                        children: [
                                            "$",
                                            item.unit_price
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "mt-5 text-lg ",
                                    children: [
                                        "$",
                                        item.unit_price * prodcutone.count || 0
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: " mt-10 mb-5 md:mt-10 md:mb-0",
                                    children: [
                                        (prodcutone.count == undefined || prodcutone.count < 1) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: "disabled:opacity-50 bg-[#8DC14F] px-2 py-[8px] rounded w-full",
                                            onClick: (e)=>{
                                                // const cartItems: [any] = JSON.parse(localStorage.getItem("cartItems")!) ?? []
                                                // const product = cartItems.find(it => it._id === item._id)
                                                // if (product) {
                                                //     product.quantity = count
                                                // } else {
                                                //     cartItems.push({ _id: item._id, quantity: count })
                                                // }
                                                // localStorage.setItem("cartItems", JSON.stringify(cartItems))
                                                // handler(e);
                                                dispatch((0,_features_cart_cartSlice__WEBPACK_IMPORTED_MODULE_4__/* .addItem */ .jX)(item));
                                                const newQuantity = (prodcutone.count || 0) + 1;
                                                dispatch((0,_features_product_productSlice__WEBPACK_IMPORTED_MODULE_5__/* .updateProductQuantity */ .Ic)({
                                                    productId: item._id,
                                                    count: newQuantity
                                                }));
                                                console.log(prodcutone.count);
                                                setChangecolor(true);
                                                const map = new Map();
                                                map.set("product_id", prodcutone._id);
                                                map.set("isClicked", true);
                                                // Convert the map to a string using JSON serialization
                                                const mapString = JSON.stringify(Array.from(map.entries()));
                                                // Save the map string in the session storage
                                                sessionStorage.setItem("mapData", mapString);
                                            },
                                            children: "Add to cart"
                                        }),
                                        prodcutone.count >= 1 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex flex-raw ",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        className: "px-3 text-lg text-white bg-black",
                                                        onClick: decreaseClick,
                                                        children: "-"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "w-10 text-lg text-center bg-gray-300",
                                                        children: prodcutone.count
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                        className: "px-3 text-lg text-white bg-black ",
                                                        onClick: increaseClick,
                                                        children: "+"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AddToCartModal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5607:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_request__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1583);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8098);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_ri__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _CheckoutPop_CheckoutPop__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8297);
/* harmony import */ var _Print_Print__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(81);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1111);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_hi__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_request__WEBPACK_IMPORTED_MODULE_2__, _CheckoutPop_CheckoutPop__WEBPACK_IMPORTED_MODULE_4__, _Print_Print__WEBPACK_IMPORTED_MODULE_5__]);
([_utils_request__WEBPACK_IMPORTED_MODULE_2__, _CheckoutPop_CheckoutPop__WEBPACK_IMPORTED_MODULE_4__, _Print_Print__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const NavbarCartModal = ({ ref  })=>{
    const [cartObj, setCartObj] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [checkout, setCheckout] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [print, setPrint] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const items = JSON.parse(localStorage.getItem("cartItems")) ?? [];
        console.log(items);
        if (items.length > 0) {
            fetch(_utils_request__WEBPACK_IMPORTED_MODULE_2__/* ["default"].getCatalogBookPageItemByIds */ .Z.getCatalogBookPageItemByIds, {
                method: "post",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    items: items.map((i)=>i._id)
                })
            }).then((response)=>response.json()).then((responseJson)=>{
                const cloneResponse = [
                    ...responseJson
                ];
                cloneResponse.map((item)=>{
                    const product = items.find((i)=>i._id === item._id);
                    item.cartQuantity = product?.quantity ? product?.quantity : 0;
                });
                setCartObj(groupBy([
                    ...cloneResponse
                ], (v)=>v.shop_id.shop_name));
            }).catch((error)=>{
                console.error(error);
            });
        }
    }, []);
    const groupBy = (x, f)=>x.reduce((a, b, i)=>((a[f(b, i, x)] ||= []).push(b), a), {});
    const handleCart = (item, type, shop)=>{
        console.log(item);
        if (type === "-") {
            if (item.cartQuantity <= 0) return;
            item.cartQuantity -= 1;
        } else {
            if (item.cartQuantity >= item.quantity) return;
            item.cartQuantity += 1;
        }
        let cartShop = cartObj[shop];
        const filtered = cartShop.filter((it)=>it._id !== item._id);
        filtered.push(item);
        setCartObj({
            ...cartObj,
            [shop]: filtered
        });
    // setCartObj(cartShop)
    };
    console.log(cartObj);
    const getShopAmount = (items)=>{
        return items.reduce((a, b)=>{
            a += b.cartQuantity * b.unit_price;
            return a;
        }, 0);
    };
    const getTotalAmount = ()=>{
        console.log();
        const allItems = Object.keys(cartObj).map((shop)=>{
            return cartObj[shop];
        }).flatMap((a)=>a);
        return allItems.reduce((a, b)=>{
            a += b.cartQuantity * b.unit_price;
            return a;
        }, 0);
    };
    const togglepopup = ()=>{
        setCheckout(true);
    };
    const toggleprint = ()=>{
        setPrint(true);
    };
    const handleDelete = ()=>{
    // const newItems = shop.filter((item)=>item._id != _id)
    // setCartObj(newItems)
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        ref: ref,
        className: "fixed inset-0 z-50 bg-slate-900 bg-opacity-0 flex justify-end top-20 max-h-[600px] ",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex flex-col w-11/12 gap-6 px-4 py-4 rounded-md shadow-md bg-gray-50 md:w-9/12 lg:w-5/12 xxl:w-2/5",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: " text-[20px] text-center mt-5 font-ff-headings flex flex-wrap justify-center ",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "text-[30px] text-center mx-2 ",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_7__.HiOutlineShoppingBag, {}),
                                " "
                            ]
                        }),
                        "Your Cart"
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex items-end justify-between pb-3 border-b-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "text-[16px]",
                            children: "Grand Total Є"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "text-[16px]",
                            children: getTotalAmount()
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "overflow-y-auto overflow-x-hidden h-[46vh] ",
                    children: Object.keys(cartObj).map((shop)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex items-center justify-between px-2 py-2 bg-gray-200 border border-gray-200 ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "relative flex items-center gap-8 rounded-lg flex-raw",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                src: cartObj[shop][0]?.shop_id?.logo_img,
                                                alt: "fly",
                                                className: "object-contain w-full h-8"
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: "text-[16px]",
                                            children: shop
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: "  "
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "text-[16px]",
                                            children: [
                                                "Є: ",
                                                getShopAmount(cartObj[shop])
                                            ]
                                        })
                                    ]
                                }),
                                cartObj[shop].sort((a, b)=>a.product_name.localeCompare(b.product_name)).map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "grid grid-cols-8 gap-1 py-2",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "overflow-hidden rounded-lg ",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    src: item.product_image,
                                                    alt: "fly",
                                                    className: "object-contain w-full h-20"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-span-3 ml-2",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "text-[16px]",
                                                        children: item.product_name
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                        className: "text-gray-400 text-[16px]",
                                                        children: [
                                                            "Є ",
                                                            item.unit_price
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "mx-auto flex items-end pb-0.5",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_3__.RiDeleteBinLine, {
                                                        onClick: ()=>handleDelete(),
                                                        className: "text-2xl text-red-400"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "col-span-2 text-right ",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                        className: "mb-5",
                                                        children: [
                                                            "Є ",
                                                            item.cartQuantity * item.unit_price
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "flex items-center justify-between w-full col-span-2 px-4 py-1 border-2 border-green-800 rounded-md",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "flex items-center",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                    className: "text-[16px] text-green-800 ",
                                                                    onClick: ()=>handleCart(item, "-", shop),
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_6__.FaMinus, {})
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "flex items-center",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                    className: "w-10 text-[16px] text-center ",
                                                                    children: item.cartQuantity
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "flex items-center",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                    className: "flex items-center text-[16px] text-green-800",
                                                                    onClick: ()=>handleCart(item, "+", shop),
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_6__.FaPlus, {})
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }, `item${shop + index}`))
                            ]
                        }, `shop${shop}`))
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex justify-between mt-12 mb-4",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            disabled: Object.keys(cartObj).length === 0,
                            className: `bg-[#8DC14F] text-white rounded-lg px-2 py-2 flex-1 mx-1 ${Object.keys(cartObj).length === 0 ? "bg-opacity-50" : ""}`,
                            onClick: ()=>{
                                localStorage.removeItem("cartItems");
                                setCartObj({});
                            },
                            children: "Clear cart"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            onClick: togglepopup,
                            disabled: Object.keys(cartObj).length === 0,
                            className: `bg-[#8DC14F] text-white rounded-lg px-2 py-2 flex-1 mx-1 ${Object.keys(cartObj).length === 0 ? "bg-opacity-50" : ""}`,
                            children: "Checkout"
                        }),
                        checkout && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CheckoutPop_CheckoutPop__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                setCheckout: setCheckout,
                                cartObj: cartObj,
                                getShopAmount: getShopAmount,
                                getTotalAmount: getTotalAmount,
                                handleCart: handleCart
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            onClick: toggleprint,
                            className: `bg-[#8DC14F] text-white rounded-lg px-2 py-2 flex-1 mx-1 `,
                            children: "Print"
                        }),
                        print && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Print_Print__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                setPrint: setPrint
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavbarCartModal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2214:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Catalog_SingleItemPreview)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./assets/right/marked.png
/* harmony default export */ const marked = ({"src":"/_next/static/media/marked.8eb9e0ac.png","height":557,"width":600,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAMAAAACh/xsAAAATlBMVEX+AAAAAAD+AAD+AAD+AAD+AAD+AAD+AAD+AAD+AAD+AAD+AAD+AAD+AAD+AAD+AAD+AAD+AAD+AAD+AAD+AAD+AAD+AAD+AAD+AAD+AAAP6et5AAAAGXRSTlMAAAECAwQFERIXM1JWWX6BiIqPl6LIycrwlEXNDQAAADJJREFUeNoFwIURgDAMAMAntLh791+UUxHJuCJqyxXk5HyQ2L6QHNNcBpn2LrsGurcX/CoxAXgm23uFAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: ./src/components/Catalog/SingleItemPreview.tsx





const SingleItemPreview = ({ strokeImageUrl , coordinates , imageWidth , imageHeight , handleSelection , width , height , changecolor  })=>{
    const dispatch = (0,external_react_redux_.useDispatch)();
    const products = (0,external_react_redux_.useSelector)((state)=>state.product.products);
    const theproduct = products.find((product)=>product._id === coordinates.id);
    // console.log({width, height, imageWidth, imageHeight, coordinates})
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        style: {
            position: "relative",
            maxWidth: width,
            height,
            userSelect: "none"
        },
        children: strokeImageUrl && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    style: {
                        maxWidth: width,
                        height,
                        width,
                        background: `url(${strokeImageUrl})`,
                        backgroundSize: "cover",
                        backgroundRepeat: "no-repeat"
                    }
                }),
                coordinates.map((crop, index)=>{
                    const scaleX = width / imageWidth;
                    const scaleY = height / imageHeight;
                    return theproduct?.count >= 1 ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "selection-div",
                        style: {
                            background: "rgba(255, 255, 255, 0.1)",
                            width: crop.width * scaleX,
                            height: crop.height * scaleY,
                            transform: `translate(${crop.x * scaleX}px, ${crop.y * scaleY}px)`,
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center"
                        },
                        onClick: ()=>handleSelection({
                                crop: {
                                    ...crop,
                                    imageWidth,
                                    imageHeight
                                },
                                index,
                                imageWidth,
                                imageHeight,
                                itemId: crop.id,
                                itemName: crop.name
                            }),
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: marked,
                            alt: "LOGO",
                            className: "h-11 sm:h-9 md:h-11 w-auto",
                            style: {
                                width: `${crop.width * scaleX * 0.8}px`,
                                height: `${crop.height * scaleY * 0.8}px`
                            }
                        })
                    }, `interactive-div-${index}`) : /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "selection-div",
                        style: {
                            background: "white",
                            opacity: 0.5,
                            width: crop.width * scaleX,
                            height: crop.height * scaleY,
                            transform: `translate(${crop.x * scaleX}px, ${crop.y * scaleY}px)`
                        },
                        onClick: ()=>handleSelection({
                                crop: {
                                    ...crop,
                                    imageWidth,
                                    imageHeight
                                },
                                index,
                                imageWidth,
                                imageHeight,
                                itemId: crop.id,
                                itemName: crop.name
                            })
                    }, `interactive-div-${index}`);
                })
            ]
        })
    });
};
/* harmony default export */ const Catalog_SingleItemPreview = (SingleItemPreview);


/***/ }),

/***/ 5651:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _pages_catalog_preview_catalogId___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(330);
/* harmony import */ var _Catalog_SingleItemPreview__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2214);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_pages_catalog_preview_catalogId___WEBPACK_IMPORTED_MODULE_2__]);
_pages_catalog_preview_catalogId___WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




function Draggable({ pages , setShowModal , changecolor , item  }) {
    const [isDragging, setIsDragging] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [dragStartX, setDragStartX] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [scrollLeft, setScrollLeft] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const containerRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const [currentIndex, setCurrentIndex] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        index: 0,
        direction: true
    });
    const itemRefs = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)([]);
    const observer = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const [windowInfo, setWindowInfo] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        width: 0,
        height: 0
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setWindowInfo({
            width: window.innerWidth,
            height: window.innerHeight
        });
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        observer.current = new IntersectionObserver(handleIntersect, {
            threshold: 1
        });
        const items = itemRefs.current;
        items.forEach((item)=>observer.current.observe(item));
        return ()=>{
            if (observer.current) {
                observer.current.disconnect();
            }
        };
    }, [
        pages,
        currentIndex,
        isDragging
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (pages.length > 0) {
            itemRefs.current[currentIndex.index].scrollIntoView({
                inline: "center",
                behavior: "smooth"
            });
        }
    }, [
        currentIndex,
        pages
    ]);
    const handleMouseDown = (event)=>{
        setIsDragging(true);
        setDragStartX(event.clientX);
        setScrollLeft(containerRef.current.scrollLeft);
    };
    const handleMouseMove = (event)=>{
        if (!isDragging) {
            return;
        }
        const dragDistance = event.clientX - dragStartX;
        containerRef.current.scrollLeft = scrollLeft - dragDistance;
    };
    const handleMouseUp = ()=>{
        setIsDragging(false);
    };
    const handleIntersect = (entries)=>{
        console.log(entries);
        entries.forEach((entry)=>{
            if (entry.isIntersecting && entry.intersectionRatio === 1) {
                if (isDragging) {
                    console.log("intersecting", {
                        currentIndex,
                        length: pages.length
                    }, entry.target.dataset.index);
                    const newIndex = parseInt(entry.target.dataset.index);
                    setCurrentIndex((prevIndex)=>({
                            ...prevIndex,
                            index: newIndex
                        }));
                }
            }
        });
    };
    console.log({
        ...currentIndex
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_catalog_preview_catalogId___WEBPACK_IMPORTED_MODULE_2__.PrevArrowCircle, {
                className: `arrow left`,
                onClick: ()=>{
                    setCurrentIndex((prevIndex)=>({
                            ...prevIndex,
                            direction: false,
                            index: (prevIndex.index + pages.length - 1) % pages.length
                        }));
                }
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                ref: containerRef,
                className: "draggable-container",
                onMouseDown: handleMouseDown,
                onMouseMove: handleMouseMove,
                onMouseUp: handleMouseUp,
                onMouseLeave: handleMouseUp,
                onMouseUpCapture: handleMouseUp,
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "counter",
                        children: [
                            currentIndex.index + 1,
                            "/",
                            pages.length
                        ]
                    }),
                    pages.length > 0 && pages.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            ref: (el)=>itemRefs.current[index] = el,
                            "data-index": index,
                            children: item.items && item.items.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Catalog_SingleItemPreview__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                coordinates: item.items.map((it)=>({
                                        ...it.coordinates,
                                        id: it._id,
                                        name: it.product_name
                                    })).flatMap((a)=>a),
                                strokeImageUrl: item.page_image,
                                height: windowInfo.height - 16 * 7,
                                width: item?.items[0]?.coordinates?.imageWidth * (windowInfo.height - 16 * 7) / item?.items[0]?.coordinates?.imageHeight,
                                handleSelection: ({ itemId , itemName  })=>{
                                    const selectedProduct = item.items.find((it)=>it._id === itemId);
                                    setShowModal({
                                        show: true,
                                        item: selectedProduct
                                    });
                                },
                                imageHeight: item?.items[0]?.coordinates?.imageHeight,
                                imageWidth: item?.items[0]?.coordinates?.imageWidth,
                                changecolor: changecolor
                            })
                        }, `page-slider-${index}`))
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_pages_catalog_preview_catalogId___WEBPACK_IMPORTED_MODULE_2__.NextArrowCircle, {
                className: `arrow right`,
                onClick: ()=>{
                    setCurrentIndex((prevIndex)=>({
                            ...prevIndex,
                            direction: true,
                            index: (prevIndex.index + 1) % pages.length
                        }));
                }
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Draggable);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 782:
/***/ (() => {



/***/ }),

/***/ 8278:
/***/ (() => {



/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 8547:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/gr");

/***/ }),

/***/ 1111:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/hi");

/***/ }),

/***/ 9989:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/io5");

/***/ }),

/***/ 8098:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ri");

/***/ }),

/***/ 5065:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/sl");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 53:
/***/ ((module) => {

"use strict";
module.exports = require("react-to-print");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [121,675,676,664,250,705,631,236], () => (__webpack_exec__(330)));
module.exports = __webpack_exports__;

})();