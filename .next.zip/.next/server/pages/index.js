(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 4186:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _src_components_Header_Header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2690);
/* harmony import */ var _src_components_Main_Main__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7341);
/* harmony import */ var _src_components_LatestFlyers_LatestFlyers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2266);
/* harmony import */ var _src_components_News_News__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6279);
/* harmony import */ var _src_components_Category_Category__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9343);
/* harmony import */ var _src_components_Shops_Shops__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5727);
/* harmony import */ var _src_components_LatestItems_LatestItems__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6779);
/* harmony import */ var _src_components_Cities_Cities__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6556);
/* harmony import */ var _utils_request__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1583);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _src_components_SpecialFlyers_Ad__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2689);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(1377);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _src_features_product_ProductList__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(4610);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_components_Header_Header__WEBPACK_IMPORTED_MODULE_1__, _src_components_Main_Main__WEBPACK_IMPORTED_MODULE_2__, _utils_request__WEBPACK_IMPORTED_MODULE_9__, _src_features_product_ProductList__WEBPACK_IMPORTED_MODULE_14__]);
([_src_components_Header_Header__WEBPACK_IMPORTED_MODULE_1__, _src_components_Main_Main__WEBPACK_IMPORTED_MODULE_2__, _utils_request__WEBPACK_IMPORTED_MODULE_9__, _src_features_product_ProductList__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















const Home = ({ catalogs , shops , items , news , categories  })=>{
    const [userCoordinates, setUserCoordinates] = (0,react__WEBPACK_IMPORTED_MODULE_10__.useState)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_12__.useRouter)();
    const { t  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_13__.useTranslation)();
    (0,react__WEBPACK_IMPORTED_MODULE_10__.useEffect)(()=>{
        getLocation();
        console.log(news);
        console.log(categories);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_10__.useEffect)(()=>{
        console.log(userCoordinates?.coords);
        if (userCoordinates?.coords) {
            const query = {
                lat: userCoordinates.coords.latitude,
                long: userCoordinates.coords.longitude
            };
            router.replace({
                pathname: `/`,
                query
            }, undefined, {
                shallow: false
            });
        }
    }, [
        userCoordinates
    ]);
    function getLocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(setUserCoordinates);
        }
    }
    // console.log(shops)
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Header_Header__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Main_Main__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                catalogs: catalogs
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_SpecialFlyers_Ad__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                className: "mx-auto px-10 flex flex-col gap-10 my-10",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Category_Category__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        categories: categories
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_LatestFlyers_LatestFlyers__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                        catalogs: catalogs
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Shops_Shops__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        shops: shops
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_LatestItems_LatestItems__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        items: items
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_features_product_ProductList__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_News_News__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        allnews: news
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_Cities_Cities__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        shops: shops
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Home);
const getServerSideProps = async (context)=>{
    const url = context.query.long && context.query.lat ? `${_utils_request__WEBPACK_IMPORTED_MODULE_9__/* ["default"].fetchCatelogs */ .Z.fetchCatelogs}?long=${context.query.long}&lat=${context.query.lat}` : _utils_request__WEBPACK_IMPORTED_MODULE_9__/* ["default"].fetchCatelogs */ .Z.fetchCatelogs;
    const [catalogs, items, shops, news, categories] = await Promise.all([
        fetch(url).then((res)=>res.json()),
        fetch(_utils_request__WEBPACK_IMPORTED_MODULE_9__/* ["default"].getLatestItemId */ .Z.getLatestItemId).then((res)=>res.json()),
        fetch(_utils_request__WEBPACK_IMPORTED_MODULE_9__/* ["default"].allShops */ .Z.allShops).then((res)=>res.json()),
        fetch(_utils_request__WEBPACK_IMPORTED_MODULE_9__/* ["default"].allNews */ .Z.allNews).then((res)=>res.json()),
        fetch(_utils_request__WEBPACK_IMPORTED_MODULE_9__/* ["default"].allCategory */ .Z.allCategory).then((res)=>res.json())
    ]);
    console.log(catalogs);
    return {
        props: {
            catalogs: catalogs,
            items: items,
            shops: shops,
            news: news,
            categories: categories
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4474:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_request__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1583);
/* harmony import */ var _CheckoutPop_CheckoutPop__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8297);
/* harmony import */ var _Print_Print__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(81);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4751);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8098);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_ri__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1111);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_hi__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8625);
/* harmony import */ var react_icons_ci__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_ci__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_request__WEBPACK_IMPORTED_MODULE_2__, _CheckoutPop_CheckoutPop__WEBPACK_IMPORTED_MODULE_3__, _Print_Print__WEBPACK_IMPORTED_MODULE_4__]);
([_utils_request__WEBPACK_IMPORTED_MODULE_2__, _CheckoutPop_CheckoutPop__WEBPACK_IMPORTED_MODULE_3__, _Print_Print__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const MobileCartModal = ({ setMobileShowCart  })=>{
    const [checkout, setCheckout] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [print, setPrint] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [cartObj, setCartObj] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const animation = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    // const [isAnimating, setIsAnimating] = useState(false);
    const handleClose = ()=>{
        // setIsAnimating(true);
        setMobileShowCart(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!setMobileShowCart) {
            setTimeout(()=>{}, 500);
        }
    }, []);
    const show = ()=>{
        let id;
        let pos = 0;
        clearInterval(id);
        id = setInterval(frame, 5);
        function frame() {
            if (pos == 350) {
                clearInterval(id);
            } else {
                pos++;
                if (animation.current) {
                    animation.current.style.left = pos + "%";
                }
            }
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const items = JSON.parse(localStorage.getItem("cartItems")) ?? [];
        console.log(items);
        if (items.length > 0) {
            fetch(_utils_request__WEBPACK_IMPORTED_MODULE_2__/* ["default"].getCatalogBookPageItemByIds */ .Z.getCatalogBookPageItemByIds, {
                method: "post",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    items: items.map((i)=>i._id)
                })
            }).then((response)=>response.json()).then((responseJson)=>{
                const cloneResponse = [
                    ...responseJson
                ];
                cloneResponse.map((item)=>{
                    const product = items.find((i)=>i._id === item._id);
                    item.cartQuantity = product?.quantity ? product?.quantity : 0;
                });
                setCartObj(groupBy([
                    ...cloneResponse
                ], (v)=>v.shop_id.shop_name));
            }).catch((error)=>{
                console.error(error);
            });
        }
    }, []);
    const groupBy = (x, f)=>x.reduce((a, b, i)=>((a[f(b, i, x)] ||= []).push(b), a), {});
    const handleCart = (item, type, shop)=>{
        console.log(item);
        if (type === "-") {
            if (item.cartQuantity <= 0) return;
            item.cartQuantity -= 1;
        } else {
            if (item.cartQuantity >= item.quantity) return;
            item.cartQuantity += 1;
        }
        let cartShop = cartObj[shop];
        const filtered = cartShop.filter((it)=>it._id !== item._id);
        filtered.push(item);
        setCartObj({
            ...cartObj,
            [shop]: filtered
        });
    // setCartObj(cartShop)
    };
    console.log(cartObj);
    const getShopAmount = (items)=>{
        return items.reduce((a, b)=>{
            a += b.cartQuantity * b.unit_price;
            return a;
        }, 0);
    };
    const getTotalAmount = ()=>{
        console.log();
        const allItems = Object.keys(cartObj).map((shop)=>{
            return cartObj[shop];
        }).flatMap((a)=>a);
        return allItems.reduce((a, b)=>{
            a += b.cartQuantity * b.unit_price;
            return a;
        }, 0);
    };
    const togglepopup = ()=>{
        setCheckout(true);
    };
    const toggleprint = ()=>{
        setPrint(true);
    };
    const handleDelete = ()=>{
    // const newItems = shop.filter((item)=>item._id != _id)
    // setCartObj(newItems)
    };
    //   const styleObj = {
    //     // position: "absolute",
    //     right: !mobileShowCart?"-1500px":"0px",
    //     transition: "1s",
    //     zIndex:!mobileShowCart?"50":"",
    //     opacity:!mobileShowCart?"0px":"50px"
    // }
    //style={styleObj}
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        ref: animation,
        className: "fixed inset-0 z-50 grid mb-0 transition-transform duration-1000 transform bg-opacity-50 place-items-end bg-slate-900 hover:-translate-x-0",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "relative right-0 flex flex-col w-10/12 h-screen px-3 pt-5 bg-white rounded-md shadow-md lg:px-4 bottom-1 left-2 md:w-8/12 lg:w-3/12",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: `text-right ${setMobileShowCart ? "translate-x-0 transition ease-in-out duration-300" : "translate-x-full"}`,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        onClick: ()=>handleClose(),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_5__.IoIosClose, {
                            className: "text-2xl"
                        })
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: " text-[20px] text-center font-ff-headings flex flex-wrap justify-center ",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "text-[30px] text-center mx-2 mb-2",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_hi__WEBPACK_IMPORTED_MODULE_7__.HiOutlineShoppingBag, {}),
                                        " "
                                    ]
                                }),
                                "Your Cart"
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                            className: "mt-3 mb-5 font-bold border"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "h-[50vh] overflow-x-hidden overflow-y-auto",
                            children: Object.keys(cartObj).map((shop)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex items-center justify-between px-2 py-2 bg-gray-200 border border-gray-200 ",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "relative flex items-center gap-8 flex-raw",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        src: cartObj[shop][0]?.shop_id?.logo_img,
                                                        alt: "fly",
                                                        className: "object-contain w-full h-8"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                    className: "font-ff-headings text-[14px] ",
                                                    children: shop
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: " text-[14px]",
                                                    children: [
                                                        "Є ",
                                                        getShopAmount(cartObj[shop])
                                                    ]
                                                })
                                            ]
                                        }),
                                        cartObj[shop].sort((a, b)=>a.product_name.localeCompare(b.product_name)).map((item, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "grid w-full grid-cols-8 gap-1 py-2 pr-6 mx-4 my-4 item-center",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "overflow-hidden rounded-lg ",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                            src: item.product_image,
                                                            alt: "fly",
                                                            className: "object-contain w-full h-16"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-span-3 pl-1",
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                className: "text-[14px] font-ff-headings",
                                                                children: item.product_name
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                className: "text-gray-400 text-[14px]",
                                                                children: [
                                                                    "Є",
                                                                    item.unit_price
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "flex items-end ",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_6__.RiDeleteBinLine, {
                                                                onClick: ()=>handleDelete(),
                                                                className: "text-xl text-red-400 "
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-span-3 text-right text-[14px] ",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                                className: "mb-5 ",
                                                                children: [
                                                                    "Є ",
                                                                    item.cartQuantity * item.unit_price
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                                className: "flex justify-end flex-raw",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                            className: "px-3 text-white bg-green-800 rounded-l-md",
                                                                            onClick: ()=>handleCart(item, "-", shop),
                                                                            children: "-"
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                                            className: "w-10 text-center bg-gray-50 text-[14px] ",
                                                                            children: item.cartQuantity
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                            className: "px-3 text-white bg-green-800 rounded-r-md",
                                                                            onClick: ()=>handleCart(item, "+", shop),
                                                                            children: "+"
                                                                        })
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }, `item${shop + index}`))
                                    ]
                                }, `shop${shop}`))
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex mt-5 text-gray-500 text-[14px] mx-2 ",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ci__WEBPACK_IMPORTED_MODULE_8__.CiPercent, {
                                    className: "mt-1 mr-1 "
                                }),
                                "Have a Promo Code?"
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-end justify-between pt-3 pb-3 mx-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text-[16px] font-ff-headings",
                                    children: "Grand Total"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: " text-[16px]",
                                    children: [
                                        " Є ",
                                        getTotalAmount()
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                            className: "font-bold border-dashed"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex justify-between mt-10 ",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    disabled: Object.keys(cartObj).length === 0,
                                    className: `bg-[#8DC14F] text-white rounded-lg md:px-2 px-1 md:py-2 py-1 flex-1 mx-1 ${Object.keys(cartObj).length === 0 ? "bg-opacity-50" : ""}`,
                                    onClick: ()=>{
                                        localStorage.removeItem("cartItems");
                                        setCartObj({});
                                    },
                                    children: "Clear cart"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: togglepopup,
                                    disabled: Object.keys(cartObj).length === 0,
                                    className: `bg-[#8DC14F] text-white rounded-lg md:px-2 px-1 md:py-2 py-1 flex-1 mx-1 ${Object.keys(cartObj).length === 0 ? "bg-opacity-50" : ""}`,
                                    children: "Checkout"
                                }),
                                checkout && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CheckoutPop_CheckoutPop__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                        setCheckout: setCheckout,
                                        cartObj: cartObj,
                                        getShopAmount: getShopAmount,
                                        getTotalAmount: getTotalAmount,
                                        handleCart: handleCart
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: toggleprint,
                                    className: `bg-[#8DC14F] text-white rounded-lg md:px-2 px-1 md:py-2 py-1 flex-1 mx-1 `,
                                    children: "Print"
                                }),
                                print && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Print_Print__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                        setPrint: setPrint
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MobileCartModal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9343:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Category_Category)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/components/Cards/CategoryCard.tsx



const CategoryCard = ({ category  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "items-center w-40 h-10 gap-3 lg:h-24 md:flex justify-left",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
            href: "/category",
            className: "text-lg text-[#8DC14F] hover:text-green-800 font-semibold ",
            children: [
                category.name,
                " "
            ]
        })
    });
};
/* harmony default export */ const Cards_CategoryCard = (CategoryCard);

// EXTERNAL MODULE: ./src/components/Utils/Slider.tsx
var Slider = __webpack_require__(2420);
;// CONCATENATED MODULE: ./src/components/Category/Category.tsx



const Category = ({ categories  })=>{
    // const categoryss: Categories[] = [
    //    {
    //       image: cat_1,
    //       name: "New Flyers"
    //    },
    //    {
    //       image: cat_2,
    //       name: "Healthcare"
    //    },
    //    {
    //       image: cat_1,
    //       name: "New Flyers"
    //    },
    //    {
    //       image: cat_2,
    //       name: "Healthcare"
    //    }, {
    //       image: cat_1,
    //       name: "New Flyers"
    //    },
    //    {
    //       image: cat_2,
    //       name: "Healthcare"
    //    },
    //    {
    //       image: cat_1,
    //       name: "New Flyers"
    //    },
    //    {
    //       image: cat_2,
    //       name: "Healthcare"
    //    },
    //    {
    //       image: cat_1,
    //       name: "New Flyers"
    //    },
    //    {
    //       image: cat_2,
    //       name: "Healthcare"
    //    }, {
    //       image: cat_1,
    //       name: "New Flyers"
    //    },
    //    {
    //       image: cat_2,
    //       name: "Healthcare"
    //    },
    //    {
    //       image: cat_1,
    //       name: "New Flyers"
    //    },
    //    {
    //       image: cat_2,
    //       name: "Healthcare"
    //    },
    //    {
    //       image: cat_1,
    //       name: "New Flyers"
    //    },
    //    {
    //       image: cat_2,
    //       name: "Healthcare"
    //    }, {
    //       image: cat_1,
    //       name: "New Flyers"
    //    },
    //    {
    //       image: cat_2,
    //       name: "Healthcare"
    //    }
    // ]
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col gap-6",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "text-lg font-semibold",
                children: "CATEGORY"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "",
                children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
                    className: "w-full ",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Slider/* default */.Z, {
                        children: categories.mainCategories.concat(categories.subCategories).map((category, index)=>/*#__PURE__*/ jsx_runtime_.jsx(Cards_CategoryCard, {
                                category: category
                            }, index))
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const Category_Category = (Category);


/***/ }),

/***/ 6556:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Cities_Cities)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/components/Utils/Slider.tsx
var Slider = __webpack_require__(2420);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/components/Cards/CitiesCard.tsx



const CitiesCode = ({ city  })=>{
    return(// <div className="w-full max-w-[12.5rem] min-w-[12.5rem] h-64 rounded-md relative overflow-hidden shadow-sm transition duration-[0.4s] hover:scale-105 cursor-pointer">
    //     <Link href="/milan">
    //   <div>
    //     <Image src={city.image} fill sizes="width: 100%" alt="{city.title}" />
    //   </div>
    //   <div className="absolute bottom-0 p-2 bg-white backdrop-blur-sm bg-opacity-30 h-1/3">
    //     <h6 className="font-semibold">{city.title}</h6>
    //     <p className="text-xs">{city.description.substring(0, 50)} ...</p>
    //   </div>
    //   </Link>
    // </div>
    /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "items-center w-40 h-10 gap-3 select-none lg:h-24 md:flex justify-left",
            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/milan",
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "font-semibold text-lg text-[#6d973a] hover:text-green-800 ",
                    children: city.address.city
                })
            })
        })
    }));
};
/* harmony default export */ const CitiesCard = (CitiesCode);

;// CONCATENATED MODULE: ./src/components/Cities/Cities.tsx



const Cities = ({ shops  })=>{
    // const citys: City[] = [
    //   {
    //     image: cit1,
    //     title: "Milan",
    //     description:
    //       "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    //   },
    //   {
    //     image: cit2,
    //     title: "Bari",
    //     description:
    //       "Lorem Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    //   },
    //   {
    //     image: cit1,
    //     title: "Milan",
    //     description:
    //       "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    //   },
    //   {
    //     image: cit2,
    //     title: "Bari",
    //     description:
    //       "Lorem Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    //   },
    //   {
    //     image: cit1,
    //     title: "Milan",
    //     description:
    //       "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    //   },
    //   {
    //     image: cit2,
    //     title: "Bari",
    //     description:
    //       "Lorem Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    //   },
    // ];
    const uniqueItems = shops.filter((item, index, self)=>{
        return index === self.findIndex((t)=>t.address.city === item.address.city);
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col gap-6 ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "text-lg font-semibold",
                children: "CITIES WITH NEARBY OFFERS"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "",
                children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
                    className: "w-full",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Slider/* default */.Z, {
                        children: uniqueItems.map((city, index)=>/*#__PURE__*/ jsx_runtime_.jsx(CitiesCard, {
                                city: city
                            }, index))
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const Cities_Cities = (Cities);


/***/ }),

/***/ 2266:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ LatestFlyers_LatestFlyers)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/components/Utils/Slider.tsx
var Slider = __webpack_require__(2420);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: external "react-icons/ri"
var ri_ = __webpack_require__(8098);
// EXTERNAL MODULE: ./utils/dateParser.ts
var dateParser = __webpack_require__(6273);
;// CONCATENATED MODULE: ./src/components/Cards/LatestFlyerCard.tsx






const LatestFlyersCard = ({ flyer , onClick  })=>{
    return(// <div className='w-full h-36  ssm:h-40  lsm:h-56  llsm:h-64  sm:h-44  md:h-52 xmd:h-60  lg:h-72 xlg:h-80  xl:h-64  xxl:h-80  xxxl:h-[360px] rounded-md relative overflow-hidden shadow-sm transition duration-[0.4s] hover:scale-105 cursor-pointer' onClick={onClick}>
    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-[102px] h-36 ssm:w-32 ssm:h-40 lsm:w-[172px] lsm:h-56 llsm:w-52 llsm:h-64 sm:w-32 sm:h-44 md:w-32 md:h-52 xmd:w-[182px] xmd:h-60 lg:w-56 lg:h-72 xlg:h-80 xlg:w-64 xl:w-52 xl:h-64 xxl:w-60 xxl:h-80 xxxl:w-[300px] xxxl:h-[360px] rounded-md relative overflow-hidden shadow-sm transition duration-[0.4s] hover:scale-105 cursor-pointer",
        onClick: onClick,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: flyer.pages?.length && flyer.pages?.length > 0 ? flyer.pages[0]?.page_image : "",
                alt: "flyer",
                style: {
                    objectFit: "contain",
                    backgroundColor: "#DCDCDC",
                    width: "100%",
                    height: "100%"
                },
                // sizes='height: 100%'
                width: 450,
                height: 400
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "absolute bottom-0 flex flex-col w-full gap-1 p-2 bg-opacity-30 backdrop-blur-sm hover:bg-white",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "text-sm font-medium capitalize",
                        children: flyer.title
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-xs font-normal",
                                children: flyer.shop_id?.shop_name
                            }),
                            flyer.shop_id?.distance && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex items-center gap-1",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiPinDistanceFill, {
                                        className: "w-3 h-3"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: "text-sm font-medium",
                                        children: [
                                            " ",
                                            (flyer.shop_id?.distance / 1000).toFixed(2),
                                            " KM"
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center gap-2 mt-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaCalendar, {
                                className: "w-3 h-3"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: "text-xs font-normal",
                                children: [
                                    "until ",
                                    (0,dateParser/* dateParser */.R)(flyer.expiredate)
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const LatestFlyerCard = (LatestFlyersCard);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/components/LatestFlyers/LatestFlyers.tsx





const LatestFlyers = ({ catalogs  })=>{
    // const flyers: Flyer[] = [
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer1
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer2
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer3
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer4
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer5
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer6
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer7
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer1
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer2
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer3
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer4
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer5
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer6
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer7
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer1
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer2
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer3
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer4
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer5
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer6
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer7
    //     }
    // ]
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col w-full gap-6",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "text-lg font-semibold",
                children: "LATEST FLYERS"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "",
                children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
                    className: "w-full ",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Slider/* default */.Z, {
                        children: catalogs.map((flyer, index)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: `/catalog-preview/${flyer._id}`,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(LatestFlyerCard, {
                                    flyer: flyer
                                })
                            }, index))
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const LatestFlyers_LatestFlyers = (LatestFlyers);


/***/ }),

/***/ 6779:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Utils_Slider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2420);
/* harmony import */ var _Cards_LatestItemCard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9785);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_4__);





const LatestItems = ({ items  })=>{
    // const items: Item[] = [
    //     {
    //         name: "KREO BRICO AND CASA",
    //         price: "100.00",
    //         image: flyer1
    //     },
    //     {
    //         name: "MIGROSS SUPERSTORE",
    //         price: "12.00",
    //         image: flyer2
    //     },
    //     {
    //         name: "COMET",
    //         price: "230.00",
    //         image: flyer3
    //     },
    //     {
    //         name: "DYSON PROMO",
    //         price: "780.00",
    //         image: flyer4
    //     },
    //     {
    //         name: "DORECA",
    //         price: "23.00",
    //         image: flyer5
    //     },
    //     {
    //         name: "KREO BRICO AND CASA",
    //         price: "230.00",
    //         image: flyer6
    //     },
    //     {
    //         name: "KREO BRICO AND CASA",
    //         price: "234.00",
    //         image: flyer7
    //     },
    //     {
    //         name: "KREO BRICO AND CASA",
    //         price: "100.00",
    //         image: flyer1
    //     },
    //     {
    //         name: "MIGROSS SUPERSTORE",
    //         price: "12.00",
    //         image: flyer2
    //     },
    //     {
    //         name: "COMET",
    //         price: "230.00",
    //         image: flyer3
    //     },
    //     {
    //         name: "DYSON PROMO",
    //         price: "780.00",
    //         image: flyer4
    //     },
    //     {
    //         name: "DORECA",
    //         price: "23.00",
    //         image: flyer5
    //     },
    //     {
    //         name: "KREO BRICO AND CASA",
    //         price: "230.00",
    //         image: flyer6
    //     },
    //     {
    //         name: "KREO BRICO AND CASA",
    //         price: "234.00",
    //         image: flyer7
    //     },
    // ]
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col gap-6 ",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                className: "text-lg font-semibold",
                children: "LATEST ITEMS"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                    className: "w-full ",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Utils_Slider__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        padding: "px-4 py-4",
                        children: items.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_4___default()), {
                                href: `/catalog-preview/${item?.catelog_book_id}`,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cards_LatestItemCard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                    item: item
                                })
                            }, index))
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LatestItems);


/***/ }),

/***/ 7341:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _NearestFylers_NearestFlyers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4518);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8098);
/* harmony import */ var react_icons_ri__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_ri__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Cart_MobileCartModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4474);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8722);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9176);
/* harmony import */ var swiper_css_navigation__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(swiper_css_navigation__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2996);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(swiper_css_pagination__WEBPACK_IMPORTED_MODULE_8__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Cart_MobileCartModal__WEBPACK_IMPORTED_MODULE_4__]);
_Cart_MobileCartModal__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






// import Swiper and modules styles



const Main = ({ catalogs  })=>{
    const [login, setLogin] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [showCart, setShowCart] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [mobileShowCart, setMobileShowCart] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const handleCart = ()=>{
        setMobileShowCart(!mobileShowCart);
    };
    const [query, setQuery] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const handleChange = (e)=>{
        setQuery(e.target.value);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
        className: "px-10 mx-auto mt-24 overflow-y-hidden",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "relative ",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    onClick: ()=>handleCart(),
                    className: `fixed z-50 p-2 text-4xl bg-white border border-green-800 rounded-full shadow-lg right-2 bottom-2 hover:bg-gray-200 scroll-hidden ${mobileShowCart ? "scale-0 transition ease-in-out duration-300" : "scale-100"}`,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ri__WEBPACK_IMPORTED_MODULE_3__.RiShoppingCart2Fill, {
                        className: "text-green-800"
                    })
                })
            }),
            mobileShowCart && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cart_MobileCartModal__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    setMobileShowCart: setMobileShowCart,
                    mobileShowCart: mobileShowCart
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between w-full md:hidden ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        className: "w-full text-[#3D3B3B] text-sm font-light rounded-l-md px-5",
                        type: "text",
                        placeholder: "Search by Category or Items",
                        value: query,
                        onChange: handleChange
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_5__.FaSearch, {
                            className: " text-white bg-[#008C45] w-12 h-[40px] px-4 rounded-r-md"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex justify-between w-full mt-5 md:hidden",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        className: "w-full text-[#3D3B3B] text-sm font-light rounded-l-md px-5",
                        type: "text",
                        placeholder: "Search by Location",
                        value: query,
                        onChange: handleChange
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_5__.FaLocationArrow, {
                            className: " text-white bg-blue-400 w-12 h-[40px] px-4 rounded-r-md"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                className: "pt-4 mb-6 text-lg font-semibold",
                children: "NEAREST FLYERS"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                    className: "w-full h-[74vh] ",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NearestFylers_NearestFlyers__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        catalogs: catalogs
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Main);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4518:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ NearestFylers_NearestFlyers)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/components/Utils/Card.tsx
var Card = __webpack_require__(7070);
// EXTERNAL MODULE: ./src/components/Utils/Button.tsx
var Button = __webpack_require__(8084);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: external "react-icons/ri"
var ri_ = __webpack_require__(8098);
// EXTERNAL MODULE: ./utils/dateParser.ts
var dateParser = __webpack_require__(6273);
;// CONCATENATED MODULE: ./src/components/Cards/FlyerCard.tsx






const FlyerCard = ({ flyer , onClick  })=>{
    (0,external_react_.useEffect)(()=>{
        console.log(flyer);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "w-full h-36 ssm:h-40 lsm:h-56 llsm:h-64 sm:h-44 md:h-52 xmd:h-60 lg:h-72 xlg:h-80 xl:h-64 xxl:h-80 xxxl:h-[360px] rounded-md relative overflow-hidden shadow-sm transition duration-[0.4s] hover:scale-105 cursor-pointer",
        onClick: onClick,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: flyer.pages?.length && flyer.pages?.length > 0 ? flyer.pages[0]?.page_image : "",
                style: {
                    objectFit: "cover",
                    backgroundColor: "gray"
                },
                alt: "flyer",
                sizes: "height: 100%",
                height: 600,
                width: 400
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "absolute bottom-0 flex flex-col w-full gap-1 p-2 bg-opacity-30 backdrop-blur-sm hover:bg-white",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                        className: "text-sm font-medium capitalize",
                        children: flyer.title
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "text-xs font-normal",
                                children: flyer.shop_id?.shop_name
                            }),
                            flyer.shop_id?.distance && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex items-center gap-1",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiPinDistanceFill, {
                                        className: "w-3 h-3"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                                        className: "text-sm font-medium",
                                        children: [
                                            " ",
                                            (flyer.shop_id?.distance / 1000).toFixed(2),
                                            " KM"
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex items-center gap-2 mt-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaCalendar, {
                                className: "w-3 h-3"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                className: "text-xs font-normal",
                                children: [
                                    "until ",
                                    (0,dateParser/* dateParser */.R)(flyer.expiredate)
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Cards_FlyerCard = (FlyerCard);

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/components/NearestFylers/NearestFlyers.tsx






const NearestFlyers = ({ catalogs  })=>{
    const [selectedCatalog, setSelectedCatalog] = (0,external_react_.useState)();
    const [visible, setVisible] = (0,external_react_.useState)(8);
    // const flyers: Flyer[] = [
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer1
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer2
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer3
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer4
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer5
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer6
    //     },
    //     {
    //         title: "KREO BRICO AND CASA",
    //         shopName: "shopName",
    //         distance: "10KM",
    //         date: "Untill 24 september",
    //         flyer: flyer7
    //     }
    // ]
    const showMoreItem = ()=>{
        setVisible((prevValue)=>prevValue + 8);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Card/* default */.Z, {
        styleClass: "rounded-md flex flex-col gap-4 h-[80vh] overflow-hidden w-full pb-16",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-full h-[80vh] pr-2 grid grid-cols-2 gap-x-2 gap-y-5 justify-items-center overflow-y-scroll overflow-x-hidden !scrollbar-thin !scrollbar-track-transparent !scrollbar-thumb-gray-400 sm:grid-cols-4 xxl:grid-cols-4 ",
                children: catalogs.slice(0, visible).map((catelog, index)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: `/catalog-preview/${catelog._id}`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Cards_FlyerCard, {
                            flyer: catelog
                        })
                    }, index))
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "lg:mb-5",
                children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                    styleClass: "w-full bg-[#8DC14F] py-2 px-6 text-base font-medium text-white rounded-md hover:bg-[#8DC14F]/80 ",
                    onClick: showMoreItem,
                    children: "Load Nearest Flyers"
                })
            })
        ]
    });
};
/* harmony default export */ const NearestFylers_NearestFlyers = (NearestFlyers);


/***/ }),

/***/ 6279:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ News_News)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/components/Utils/Slider.tsx
var Slider = __webpack_require__(2420);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/components/Cards/NewsCard.tsx




const NewsCard = ({ news  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "space-y-4 my-6 max-w-[16rem] min-w-[12.5rem] h-96 w-64 ",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "overflow-hidden rounded-md",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: news.image,
                    alt: news.title,
                    style: {
                        objectFit: "cover",
                        backgroundColor: "gray",
                        width: "100%",
                        height: "230px"
                    },
                    sizes: "height: 100%"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-col w-full h-24 px-1 whitespace-no-wrap",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                        className: "text-xl font-semibold text-left ",
                        children: news.title
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "w-full mt-2 text-xs text-justify text-gray-600",
                        children: [
                            news.description.substring(0, 125),
                            " ..."
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "text-center ",
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/print",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "text-[#CD212A] border border-[#CD212A] px-8 rounded-md hover:bg-[#CD212A] hover:text-white",
                        children: "Read More"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const Cards_NewsCard = (NewsCard);

;// CONCATENATED MODULE: ./src/components/News/News.tsx




const News = ({ allnews  })=>{
    // const newss: News[] = [
    //   {
    //     image: news1,
    //     title: "Event for Halloween",
    //     description:
    //       "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Lorem",
    //   },
    //   {
    //     image: news2,
    //     title: "LIDL",
    //     description:
    //       "Lorem Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.",
    //   },
    // ];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col w-full gap-6",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "text-lg font-semibold",
                children: "NEWS"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "",
                children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
                    className: "w-full ",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Slider/* default */.Z, {
                        children: allnews.map((news, index)=>/*#__PURE__*/ jsx_runtime_.jsx(Cards_NewsCard, {
                                news: news
                            }, index))
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const News_News = (News);


/***/ }),

/***/ 5727:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Utils_Slider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2420);
/* harmony import */ var _Cards_ShopsCard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2662);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);




const Shops = ({ shops  })=>{
    // const shopss: Shop[] = [
    //   {
    //     image: sp_1,
    //     name: "LIDL",
    //     address: "Lorem Lorem",
    //   },
    //   {
    //     image: sp_2,
    //     name: "euronics",
    //     address: "Lorem Lorem",
    //   },
    //   {
    //     image: sp_1,
    //     name: "LIDL",
    //     address: "Lorem Lorem",
    //   },
    //   {
    //     image: sp_2,
    //     name: "euronics",
    //     address: "Lorem Lorem",
    //   },
    //   {
    //     image: sp_1,
    //     name: "LIDL",
    //     address: "Lorem Lorem",
    //   },
    //   {
    //     image: sp_2,
    //     name: "euronics",
    //     address: "Lorem Lorem",
    //   },
    //   {
    //     image: sp_1,
    //     name: "LIDL",
    //     address: "Lorem Lorem",
    //   },
    //   {
    //     image: sp_2,
    //     name: "euronics",
    //     address: "Lorem Lorem",
    //   },
    // ];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "flex flex-col w-full gap-6",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                className: "text-lg font-semibold",
                children: "SHOPS"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                    className: "w-full ",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Utils_Slider__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                        padding: "px-10 py-10",
                        children: shops.map((shop, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                href: `/shop-preview/${shop._id}`,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Cards_ShopsCard__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    shop: shop
                                }, index)
                            }, index))
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Shops);


/***/ }),

/***/ 2689:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ SpecialFlyers_Ad)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./assets/flyers/flyer_1.jpg
var flyer_1 = __webpack_require__(1143);
// EXTERNAL MODULE: ./assets/flyers/flyer_2.jpg
var flyer_2 = __webpack_require__(5045);
;// CONCATENATED MODULE: ./assets/ad/googleads.jpg
/* harmony default export */ const googleads = ({"src":"/_next/static/media/googleads.48f3c883.jpg","height":1200,"width":1200,"blurDataURL":"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoKCgoKCgsMDAsPEA4QDxYUExMUFiIYGhgaGCIzICUgICUgMy03LCksNy1RQDg4QFFeT0pPXnFlZXGPiI+7u/sBCgoKCgoKCwwMCw8QDhAPFhQTExQWIhgaGBoYIjMgJSAgJSAzLTcsKSw3LVFAODhAUV5PSk9ecWVlcY+Ij7u7+//CABEIAAgACAMBIgACEQEDEQH/xAAnAAEBAAAAAAAAAAAAAAAAAAAABwEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEAMQAAAArwP/xAAeEAABAwQDAAAAAAAAAAAAAAARAQISAAQUISRSwf/aAAgBAQABPwDlNu00zHirV7EGXgr/xAAVEQEBAAAAAAAAAAAAAAAAAAAAUf/aAAgBAgEBPwCP/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAgBAwEBPwB//9k=","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: external "react-icons/ri"
var ri_ = __webpack_require__(8098);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/components/Cards/AdCard.tsx







const AdCard = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex justify-between px-20 py-12 bg-white rounded-md ",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-[300px] min-w-[12.5rem] h-[340px] rounded-sm relative overflow-hidden shadow-sm transition duration-[0.4s] hover:scale-105 cursor-pointer ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: flyer_1/* default */.Z,
                        style: {
                            objectFit: "cover"
                        },
                        sizes: "height: 100%",
                        height: 600,
                        width: 400,
                        alt: "flyer"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "absolute bottom-0 flex flex-col w-full gap-1 p-2 bg-white bg-opacity-30 backdrop-blur-sm ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                className: "text-sm font-medium capitalize",
                                children: "KREO BRICO AND CASA"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex items-center justify-between",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-xs font-normal",
                                        children: "shop name"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex items-center gap-1",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiPinDistanceFill, {
                                                className: "w-3 h-3"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "text-sm font-medium",
                                                children: "10KM"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex items-center gap-2 mt-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaCalendar, {
                                        className: "w-3 h-3"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-xs font-normal",
                                        children: "Untill 24 september"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "h-[340px] w-auto mx-6",
                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: googleads,
                    alt: "ads",
                    style: {
                        objectFit: "cover"
                    },
                    sizes: "height: 100%",
                    height: 600,
                    width: 400
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-[300px] min-w-[12.5rem] h-[340px] rounded-sm relative overflow-hidden shadow-sm transition duration-[0.4s] hover:scale-105 cursor-pointer z-10",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: flyer_2/* default */.Z,
                        style: {
                            objectFit: "cover"
                        },
                        sizes: "height: 100%",
                        height: 600,
                        width: 400,
                        alt: "flyer"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "absolute bottom-0 flex flex-col w-full gap-1 p-2 bg-white bg-opacity-30 backdrop-blur-sm",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                className: "text-sm font-medium capitalize",
                                children: "KREO BRICO AND CASA"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex items-center justify-between",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-xs font-normal",
                                        children: "shop name"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex items-center gap-1",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(ri_.RiPinDistanceFill, {
                                                className: "w-3 h-3"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "text-sm font-medium",
                                                children: "10KM"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex items-center gap-2 mt-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaCalendar, {
                                        className: "w-3 h-3"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "text-xs font-normal",
                                        children: "Untill 24 september"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Cards_AdCard = (AdCard);

;// CONCATENATED MODULE: ./src/components/SpecialFlyers/Ad.tsx




const Ad = ()=>{
    const ads = [
        {
            title: "KREO BRICO AND CASA",
            shopName: "shopName",
            distance: "10KM",
            date: "Untill 24 september",
            flyer: flyer_1/* default */.Z
        },
        {
            title: "KREO BRICO AND CASA",
            shopName: "shopName",
            distance: "10KM",
            date: "Untill 24 september",
            flyer: flyer_2/* default */.Z
        }
    ];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "hidden px-10 mx-auto mt-8 xl:block",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                className: "mb-6 text-lg font-semibold",
                children: "SPECIAL FLYERS"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "",
                children: /*#__PURE__*/ jsx_runtime_.jsx("section", {
                    className: "w-full ",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Cards_AdCard, {})
                })
            })
        ]
    });
};
/* harmony default export */ const SpecialFlyers_Ad = (Ad);


/***/ }),

/***/ 8084:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const Button = ({ disabled , children , styleClass , id , type , onClick  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        className: styleClass,
        id: id,
        type: type ? type : "button",
        onClick: onClick,
        disabled: disabled,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Button);


/***/ }),

/***/ 2420:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8084);
/* harmony import */ var _Card__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7070);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8818);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__);





const Slider = ({ children , padding , gap  })=>{
    const rowRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    // const [isMoved, setIsMoved] = useState(false)
    const handleClick = (direction)=>{
        // setIsMoved(true)
        if (rowRef.current) {
            const { scrollLeft , clientWidth  } = rowRef.current;
            const scrollTo = direction === "left" ? scrollLeft - clientWidth / 2 : scrollLeft + clientWidth / 2;
            rowRef.current.scrollTo({
                left: scrollTo,
                behavior: "smooth"
            });
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_Card__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        padding: padding ? padding : "px-10 py-4",
        styleClass: "rounded-md relative",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                ref: rowRef,
                className: `w-full grid grid-flow-col-dense overflow-x-scroll scrollbar-hide ${gap ? gap : "gap-4"}`,
                children: children
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                styleClass: "absolute -left-4 top-0 bottom-0 h-9 w-9 grid place-items-center my-auto bg-white shadow-lg z-10 rounded-full",
                onClick: ()=>handleClick("left"),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiChevronLeft, {
                    className: "w-8 h-8"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Button__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                styleClass: "absolute -right-4 top-0 bottom-0 h-9 w-9 grid place-items-center my-auto bg-white shadow-lg z-10 rounded-full",
                onClick: ()=>handleClick("right"),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiChevronRight, {
                    className: "w-8 h-8"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Slider);


/***/ }),

/***/ 9626:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ ProductCard)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_sl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5065);
/* harmony import */ var react_icons_sl__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_sl__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8818);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _cart_cartSlice__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5250);
/* harmony import */ var _productSlice__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4631);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _utils_request__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1583);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_cart_cartSlice__WEBPACK_IMPORTED_MODULE_7__, _productSlice__WEBPACK_IMPORTED_MODULE_8__, _utils_request__WEBPACK_IMPORTED_MODULE_10__]);
([_cart_cartSlice__WEBPACK_IMPORTED_MODULE_7__, _productSlice__WEBPACK_IMPORTED_MODULE_8__, _utils_request__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











// import baseUrl from "../../../utils/baseUrl";

const ProductCard = ({ product  })=>{
    const [isDiscount, setIsdiscount] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [productPopup, setProductPopup] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [wishlist, setWishlist] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useDispatch)();
    const cartItems = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.cart.items);
    let id;
    if (typeof localStorage !== "undefined") {
        id = localStorage.getItem("id");
    }
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        console.log(product);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (product.discount >= 0) {
            setIsdiscount(true);
        }
    }, []);
    const handleIncrement = (product)=>{
        // setQuantity(quantity + 1);
        const newQuantity = (product.count || 0) + 1;
        dispatch((0,_cart_cartSlice__WEBPACK_IMPORTED_MODULE_7__/* .updateItemQuantity */ .Ol)({
            itemId: product._id,
            count: newQuantity
        }));
        dispatch((0,_productSlice__WEBPACK_IMPORTED_MODULE_8__/* .updateProductQuantity */ .Ic)({
            productId: product._id,
            count: newQuantity
        }));
        dispatch((0,_cart_cartSlice__WEBPACK_IMPORTED_MODULE_7__/* .calSubTotal */ .zB)(totalAmount));
    };
    const handleDecrement = (product)=>{
        // setQuantity(quantity - 1);
        const newQuantity = Math.max((product.count || 0) - 1, 0);
        dispatch((0,_cart_cartSlice__WEBPACK_IMPORTED_MODULE_7__/* .updateItemQuantity */ .Ol)({
            itemId: product._id,
            count: newQuantity
        }));
        dispatch((0,_productSlice__WEBPACK_IMPORTED_MODULE_8__/* .updateProductQuantity */ .Ic)({
            productId: product._id,
            count: newQuantity
        }));
        if (product.count === 1) {
        // dispatch(removeFromCart(id))
        // setIsAddToCart(false)
        }
        dispatch((0,_cart_cartSlice__WEBPACK_IMPORTED_MODULE_7__/* .calSubTotal */ .zB)(totalAmount));
    };
    const handleaddToCart = (product)=>{
        dispatch((0,_cart_cartSlice__WEBPACK_IMPORTED_MODULE_7__/* .addItem */ .jX)(product));
        const newQuantity = (product.count || 0) + 1;
        dispatch((0,_productSlice__WEBPACK_IMPORTED_MODULE_8__/* .updateProductQuantity */ .Ic)({
            productId: product._id,
            count: newQuantity
        }));
        console.log(product._id);
        dispatch((0,_cart_cartSlice__WEBPACK_IMPORTED_MODULE_7__/* .calSubTotal */ .zB)(totalAmount));
    };
    const stars = Array.from({
        length: 5
    }, (_, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__.FaStar, {
                className: i < product.rating ? "text-yellow-500" : "text-gray-400"
            })
        }, i));
    let discountprice;
    discountprice = product.unit_price * (product.discount / 100);
    let newprice = product.unit_price - discountprice;
    const handleWishlist = async (product)=>{
        // const wishlist = JSON.parse(localStorage.getItem('wishlist'));
        // const wishlistString = localStorage.getItem('wishlist');
        // const wishlist = wishlistString ? JSON.parse(wishlistString) : [];
        const whishListObj = {
            "whishList": [
                {
                    productId: product._id,
                    front: product.front,
                    title: product.title,
                    price: product.unit_price,
                    date: new Date().toLocaleDateString("en-US", {
                        month: "long",
                        day: "numeric",
                        year: "numeric"
                    }),
                    quantity: product.quantity
                }
            ]
        };
        try {
            const response = await _utils_request__WEBPACK_IMPORTED_MODULE_10__/* .http.post */ .d.post(`/users/wishList/${id}`, whishListObj);
            console.log(response.data); // do something with the response data
        } catch (error) {
            console.log(error); // handle the error
        }
    };
    let totalAmount = 0;
    for(let i = 0; i < cartItems.length; i++){
        let item = cartItems[i];
        let subtotal = item.count * (item.price - item.price * (item.discount / 100));
        totalAmount += subtotal;
    }
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        dispatch((0,_cart_cartSlice__WEBPACK_IMPORTED_MODULE_7__/* .calSubTotal */ .zB)(totalAmount));
    });
    let proId;
    const handlepopup = (product)=>{
        setProductPopup(true);
        proId = product._id;
        console.log(proId);
    };
    let yellowstars = [];
    let graystars = [];
    for(let i1 = 1; i1 <= product.review; i1++){
        yellowstars.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__.FaStar, {}));
    }
    for(let i2 = 1; i2 <= 5 - product.review; i2++){
        graystars.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__.FaStar, {}));
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "w-full min-h-[350.24px] mx-auto bg-white border border-gray-200 overflow-hidden relative group hover:drop-shadow-lg rounded-sm",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "absolute max-w-[88.41px] max-h-[49px] flex flex-col items-start gap-1 p-2"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "max-w-[40px] max-h-[85px] ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "absolute max-w-[24px] max-h-[24px] top-2 right-2 bg-white flex items-center justify-center rounded-full h-8 w-8 hover:cursor-pointer drop-shadow-lg md:invisible group-hover:visible md:group-hover:-translate-x-3 md:group-hover:ease-in transition duration-150 hover:bg-blue-900 group/icon2",
                        onClick: ()=>handlepopup(product),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_sl__WEBPACK_IMPORTED_MODULE_3__.SlSizeFullscreen, {
                            className: "h-[10px] w-[10px] fill-blue-900 group-hover/icon2:fill-white"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: `absolute max-w-[24px] max-h-[24px] top-9 right-2 bg-white flex items-center justify-center rounded-full h-8 w-8 hover:cursor-pointer drop-shadow-lg md:invisible group-hover:visible md:group-hover:-translate-x-3 md:group-hover:ease-in transition duration-150 hover:bg-blue-900 group/icon1`,
                        onClick: ()=>handleWishlist(product),
                        children: product.isFavourite ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_2__.FaHeart, {
                            className: "h-3 w-3 fill-blue-900 group-hover/icon1:fill-white"
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_4__.FiHeart, {
                            className: "h-3 w-3 text-blue-900 group-hover/icon1:text-white"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: " max-h-[172.95px] min-h-[172.95px] min-w-[154.95px] w-full hover:cursor-pointer my-2 flex items-center justify-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                    href: `/item-preview/${product._id}`,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                        width: 172.95,
                        height: 154.95,
                        //src={product.front as string}
                        src: product.product_image,
                        alt: product.title
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mx-5 mb-1 max-h-[155.29px] max-w-[212.95] ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text-sm font-medium text-black hover:text-indigo-400 capitalize leading-tight hover:cursor-pointer line-clamp-2",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                            href: `/item-preview/${product._id}`,
                            children: product.product_name
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "my-1 font-[.6875rem] text-xs pt-2 text-green-600 uppercase font-semibold tracking-[.005em]",
                        children: product.quantity > 0 ? "In Stock" : "Out of Stock"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "text-xs pt-2 flex flex-row items-center my-1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-md text-yellow-400 flex",
                                children: yellowstars
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-md text-gray-400 flex",
                                children: graystars
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: " flex flex-row items-center",
                        children: [
                            isDiscount && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "text-gray-400 text-sm line-through mr-2 my-1 font-[1.125rem]",
                                children: [
                                    "$",
                                    product.unit_price.toFixed(2)
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "my-1 text-red-700 text-lg font-semibold",
                                children: [
                                    "$",
                                    newprice.toFixed(2)
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mx-1 border-black text-black py-2 px-4 mt-1 rounded-full md:invisible group-hover:visible md:group-hover:-translate-y-3 md:group-hover:ease-in transition duration-150",
                children: [
                    (product.count == undefined || product.count < 1) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        type: "button",
                        className: " bg-blue-900 text-white h-8 rounded-full w-full ",
                        onClick: ()=>handleaddToCart(product),
                        children: "Add to cart"
                    }),
                    product.count >= 1 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "max-h-[34px] w-full flex grid-cols-3 h-10",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "px-4 max-h-[34px] border border-gray-500 bg-slate-800 rounded-tl-3xl rounded-bl-3xl ",
                                onClick: ()=>handleDecrement(product),
                                children: "-"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "max-h-[34px] flex items-center justify-center w-full text-center border-y",
                                children: product.count || 0
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                type: "button",
                                className: "px-4 max-h-[34px] border border-gray-500 bg-yellow-500 rounded-br-3xl rounded-tr-3xl ",
                                onClick: ()=>handleIncrement(product),
                                children: "+"
                            })
                        ]
                    })
                ]
            })
        ]
    }, product._id);
}; //max-w-md

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4610:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _productSlice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4631);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ProductCard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9626);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_productSlice__WEBPACK_IMPORTED_MODULE_2__, _ProductCard__WEBPACK_IMPORTED_MODULE_4__]);
([_productSlice__WEBPACK_IMPORTED_MODULE_2__, _ProductCard__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const ProductList = ()=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();
    const products = (0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useSelector)((state)=>state.product.products);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        dispatch((0,_productSlice__WEBPACK_IMPORTED_MODULE_2__/* .fetchProducts */ .t2)());
        console.log("data ", products);
        console.log(products);
    }, [
        dispatch
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "grid grid-cols-4 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8",
        children: products.map((product)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductCard__WEBPACK_IMPORTED_MODULE_4__/* .ProductCard */ .I, {
                product: product
            }, product._id))
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductList);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6273:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ dateParser)
/* harmony export */ });
const dateParser = (dateString)=>{
    const date = new Date(dateString ? dateString : "");
    const formattedDate = date.toLocaleDateString("en-US", {
        day: "2-digit",
        month: "2-digit",
        year: "numeric"
    });
    return formattedDate;
};


/***/ }),

/***/ 9176:
/***/ (() => {



/***/ }),

/***/ 2996:
/***/ (() => {



/***/ }),

/***/ 8722:
/***/ (() => {



/***/ }),

/***/ 5184:
/***/ ((module) => {

"use strict";
module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 1377:
/***/ ((module) => {

"use strict";
module.exports = require("next-i18next");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 8625:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ci");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 8818:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fi");

/***/ }),

/***/ 8547:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/gr");

/***/ }),

/***/ 1111:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/hi");

/***/ }),

/***/ 4751:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/io");

/***/ }),

/***/ 9989:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/io5");

/***/ }),

/***/ 8098:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/ri");

/***/ }),

/***/ 5065:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/sl");

/***/ }),

/***/ 1740:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/tfi");

/***/ }),

/***/ 6022:
/***/ ((module) => {

"use strict";
module.exports = require("react-redux");

/***/ }),

/***/ 53:
/***/ ((module) => {

"use strict";
module.exports = require("react-to-print");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

"use strict";
module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [121,675,676,664,250,705,338,631,10,462,236,662], () => (__webpack_exec__(4186)));
module.exports = __webpack_exports__;

})();